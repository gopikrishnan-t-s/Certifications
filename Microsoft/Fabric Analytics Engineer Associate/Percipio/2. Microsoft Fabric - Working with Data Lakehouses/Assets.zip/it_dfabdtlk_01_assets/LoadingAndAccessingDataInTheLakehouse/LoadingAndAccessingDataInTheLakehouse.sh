####################################
# d-02-LoadingAndAccessingDataInTheLakehouse
####################################

# Dataset: https://www.kaggle.com/datasets/aungpyaeap/supermarket-sales

# Start from Synapse Data Engineering and click on the loony_lakehouse

# In the Explorer, click on the three-dots for "Files" and choose "New Subfolder"

# Call the folder

sales

# In the Explorer, click on the three-dots for "sales" and choose "Upload" -> "Files"

# Then choose the supermarket_sales.csv file and upload that

# Now click on "sales" and it will show supermarket_sales.csv

# NOTE
# Only folders are show in the Explorer on the left - files are views on the main pane

# Click on the file and view the preview

# Now click on the three-dots for the CSV file

# Choose Properties and show the properties

# Copy over the URL and paste it into empty Sublimetext to show the structure

https://onelake.dfs.fabric.microsoft.com/4fb0a083-063b-4001-9a47-283fba5da8d5/e8bf8737-66cd-41f0-9141-6155bc145fe3/Files/sales/supermarket_sales.csv

# Copy over the ABFS and paste it into Sublimetext (just below the previous URL) to show the structure

abfss://4fb0a083-063b-4001-9a47-283fba5da8d5@onelake.dfs.fabric.microsoft.com/e8bf8737-66cd-41f0-9141-6155bc145fe3/Files/sales/supermarket_sales.csv

----------------------------

# Now again click on the three-dots for the CSV file

# Choose Load to Table

# The table can be called supermarket_sales

# After it loads, click on the table and show the preview

# NOTE: The little triangular icon on the table, this indicates that this table is a Delta table

# Expand the table on the left and show the columns - note the data types have been auto-detected



# Now click on the three-dots for the table and select "Properties"

# Note that this is a delta table (Format delta)

# It is a managed table (managed by Fabric - data is actually in Fabric)

# Copy over the URL and paste it into an empty Sublimetext to show the structure
# Note that this table is under the "Tables/" folder

https://onelake.dfs.fabric.microsoft.com/4fb0a083-063b-4001-9a47-283fba5da8d5/e8bf8737-66cd-41f0-9141-6155bc145fe3/Tables/supermarket_sales

# Copy over the ABFS and paste it into Sublimetext (just below the previous URL) to show the structure

abfss://4fb0a083-063b-4001-9a47-283fba5da8d5@onelake.dfs.fabric.microsoft.com/e8bf8737-66cd-41f0-9141-6155bc145fe3/Tables/supermarket_sales


# Now click on the three-dots for the table and select "View Files"

# There is a Parquet file here, and there is a delta log folder 

# You can expand the delta log folder and show the files

# Click through the JSON file which contains details of the file versions that make up the delta table

------------------------------------------

# Now switch to the "SQL Analytics Endpoint" in the top-right
# Here expand the "dbo" schema and show the table there

# Run the same query that we ran earlier

SELECT TABLE_NAME
FROM INFORMATION_SCHEMA.TABLES
WHERE TABLE_TYPE='BASE TABLE';

# Should see the supermarket_sales table


# Run this code in the query

SELECT * FROM dbo.supermarket_sales

# Now click on the Messages tab and show that the query has run successfully

# Now show the Results

# Click on the "Explore this data" button (will need to select the query)

# Add the "ProductLine" and "Average of UnitPrice"

# Make the visual a Column Chart

# Also expand and show the matrix with the data

# Exit this view now (don't save the report)


# Now run this query:

SELECT ProductLine, AVG(UnitPrice) AS AvgUnitPrice FROM dbo.supermarket_sales GROUP BY ProductLine

# Next, we will recreate this query in the Visual Query Editor

# Click on the "New visual query" button

# Drag the supermarket_sales table onto the canvas

# Click on Transform --> Group by

# Group by: ProductLine, New column name: AvgUnitPrice, Operation: Average, Column: UnitPrice

# Now apply this and view the result

# Click on "View SQL" and view the T-SQL script that produced this result


###########
# Spark SQL
###########

# Click on the Lakehouse in the top-right
# Click on Open Notebook -> New

# Name the notebook

AccessingDataWithSpark

# Follow the steps in the AccessingDataWithSpark notebook

# Please note that this is just a preview of using Spark to work with data in Data Lakehouses. We will do a more thorough exploration of Spark to analyze data a little later on. This is a sneak peak








