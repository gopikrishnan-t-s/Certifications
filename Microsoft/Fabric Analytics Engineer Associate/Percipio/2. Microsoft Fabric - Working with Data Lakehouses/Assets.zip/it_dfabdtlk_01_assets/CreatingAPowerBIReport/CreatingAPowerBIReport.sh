#############################
# d-05-CreatingAPowerBIReport
#############################

# This demo is to show that the familiar Power BI Desktop experience is also available in Fabric on the Web. Power BI reports can be generated using data directly from the Lakehouse and Warehouse

# Dataset: https://www.kaggle.com/datasets/shekpaul/global-superstore

# Please see the screenshot for the final look of the report


# Start off in the Lakehouse

# Under Files/ create a new folder 

superstore

# Under Files/superstore/ upload the Global_Superstore.csv file

# Refresh the Files/ -> Select superstore/ and show the CSV file uploaded

# Create a table from this file, call the table

global_superstore

# Now switch to the SQL endpoint

# Select the global_superstore table and show the data

# Click on New Report and let it take all the tables there are (we will only be using the global_superstore table). This just shows all the tables that are part of the Lakehouse

------------------------------------------
# Hide the filters so you have more room for your report

# IMPORTANT: Please position the report nicely so it shows up well in 720p (you should quickly practice first)

-------------------------------------------

# Clustered column chart

# Sum of Profit by Region

# Drag the chart

# X-axis: Region

# Y-axis: Profit (sum is the automatic aggregation)

# Click on the bars in the report and show we have the same interactivity

-------------------------------------------

# Add the first card

# Sum of Profit

# Drag the profit column to this Fields

# Add the second card

# Count of Country

# Drag the Country column to the Fields

# Change to Count(Distinct)

-------------------------------------------
# Add a treemap

# Category = Category

# Values = Sum of Profit

# Details = Segment

# Go to the "Format visual" option

# Turn on "Data labels" so we get the Profit number for each category

# Select 1-2 regions and show other charts update


-------------------------------------------
# Add a map

# Location Country

# Legend Market

# Tooltip Sum of Profit

# Hover over some tooltips and show

-------------------------------------------

# Add a slicer

# Drag "Market" on to the slicer

--------------------------------------------

# Select 1-2 regions on the slicer and show the updates

# Click on "Save" at the top-right and give the report a name


Global Superstore Profit Analysis Report

# Click on the Workspace on the left and show the Report is now a Fabric item in our WS
























