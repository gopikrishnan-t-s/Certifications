###############################
# d-04-WorkingWithVisualQueries
###############################

# Behind the scenes (before starting recording)

# Clear up all the shortcuts from the previous demos

# Clear up all the tables that were created using shortcuts

# Should be left with 

Tables/supermarket_sales
Files/sales/supermarket_sales.csv

# Clear up any previous queries and visual queries that we have run (delete the queries from the SQL Analytics Endpoint view)


----------------------------------------------
# Start recording from here

# Start in the Lakehouse view

# Switch to the SQL Analytics Endpoint

# Create a new visual query and rename it 

SupermarketSalesQuery

# Drag the supermarket_sales table into it

# Click on the + and add a "Select Columns" branch

# Choose the following columns

City, 
Gender, 
ProductLine, 
UnitPrice, 
Quantity, 
Date

# Note the result pane below, we only have the selected columns in the result

# Click on "View SQL" and show the SQL queries with the columns selected

# Click on the "Power Query" icon on the top-right and show the Power Query steps in the M language

# Click on EACH step and show the M language equivalent for each step in the visual query

# Note that you can delete steps as well (don't delete anything)

# Close this view

---------------

# Make sure the "Gender" column is selected in the results

# Now click on the + next to Choose Columns -> Filter rows

Gender = Female (choose from drop down)

# Rename this step to be "Gender = Female" in the visual query

--------------
# Click on the "Table" in the Visual Query - you should be able to see all columns of the table in the result pane

# Now notice that we have a "Total" Column that we have not previously selected

# Double-click on "Choose columns" and select the "Total" column as well

# Now select the last operation we have added Filter Gender = Female

# Show the result pane - the previous changes inserted are all visible here

--------------
# Now let us add a new column

# Click on + at the very end -> Add conditional column

# Name

OrderSize

# Condition

Quantity > 7 = Large
Quantity > 4 = Medium

Else

Small

# Click on OK and see the new column

# Click on View SQL and show how our SQL script has become fairly complex

-------------------------

# Select the ProductLine column in the results

# Right-click -> Replace Values "Health and beauty" with "Cosmetics"

# Click on + and add a "Group By"

# Group by 

ProductLine

Average of Total

Column name = "Average of Total"

# Show the result

# Click on view SQL and show the SQL

-------------------------

# Click on the "Choose columns" in the Visual Query

# Now notice that the "Date" column is of data type "String" - let us change the type

# With the "Choose columns" selected, right-click on "Date" and change the data type to Date

# IMPORTANT (the Change Data Type should be AFTER the "Choose Columns")

# You should see a dialog about inserting a new column -> Say yes

# Rename this to

DateType -> Date

# Note that you get a banner that says this cannot be translated to SQL and so cannot be used to create a view. This is because there are certain parts of a query that cannot be "folded" namely the place where we change the data type of Date. This will be run using the Power Query M programming language

# Click on the icon on the top-right to bring up the Power Query editor

# Hover over each of the steps on the right hand side

# Notice that all steps AFTER the "Choose Columns" are executed outside the data source i.e. they are NOT folded

------------------------------------------------------------
# Let's see how you can directly write your steps using the M programming language

# Now let's get rid of the grouping

# Select the "Group by" -> Right-click -> Delete

# Click on the + just after the "Replaced value"

# Add a new step Choose Columns and select all (this is a placeholder)

# Now open the visual query in Power Query and go to the last step

# Replace whatever command is there with this command:
Table.AddColumn(#"Replaced value", "Year", each Date.Year([Date]), Int32.Type)


# Save this and call the step Added Year Column

# Note the results at the bottom
















