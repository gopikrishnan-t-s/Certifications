##############################
# d-01-SettingUpADataLakehouse
##############################

----------------------------------------------
# Start logged in to your Fabric free trial account

# Click on "Synapse Data Engineering"

# Note all the options that you can get started with in Synapse Data Engineering


# In that, click on Workspaces in the sidebar

# Click on "New Workspace"

# Create a workspace

# Name
loony-workspace

# Description
My demo workspace for working with Lakehouses and Spark notebooks

# Hover over the help for Domain

# Click on Advanced and show that this workspace is created using the Trial license

# Show the Semantic Model Storage format (the default to use for the workspace)

# Click on "Apply" and create the workspace



# In the home page of loony-workspace, click the "Workspace Settings"

# Just show the "General" section - scroll

# Note many settings on the left

# Then click on the "New" button and choose "Lakehouse"

# Name the lakehouse "loony_lakehouse" 

# However over the help icon for "Lakehouse schemas" (we won't use this)
# This is similar to Snowflake schemas to group objects - by default all the tables go into a default schema called "dbo"

# We're in the Explorer view - note that we can store Tables and Files in the lakehouse - both are empty

# Click on the little arrow next to tables and files to show empty


# Note the options on top to work with lakehouses (Ingest data, create semantic models, create notebooks, manage access)

# Then expand the "Get Data" and show the options there

# Now in the top-right corner of the screen, select the dropdown that is currently on "Lakehouse"

# That will show two options - one for the Lakehouse, and the other for the SQL endpoint 

-----------------------------------

# You can run SQL queries from this endpoint
# Click on the New SQL Query button and run the following query there:

# This query checks to see whether we have any tables in the lakehouse
SELECT TABLE_NAME
FROM INFORMATION_SCHEMA.TABLES
WHERE TABLE_TYPE='BASE TABLE';

# This is blank because we do not have any tables

# Now at the bottom of the screen, click on the "Model" view
# This is the default Semantic model view of the data in the lakehouse

# Click on Data - we have no data in the lakehouse so no preview

# Now click on loony-workspace and show that there are multiple Fabric items or resources here

# One is the lakehouse and within that we have the Semantic model and the SQL analytics endpoint that we used for some basic querying


















