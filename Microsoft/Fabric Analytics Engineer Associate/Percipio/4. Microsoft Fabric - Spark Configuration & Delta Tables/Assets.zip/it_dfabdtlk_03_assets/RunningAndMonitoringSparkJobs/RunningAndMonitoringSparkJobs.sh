####################################
# d-07-RunningAndMonitoringSparkJobs
####################################


# Behind the scenes set up the ComputeIndiaSalesByCity notebook complete with code

# Set up the Lakehouse attached to the notebook as well

# (do not run the code cells just have all the code ready)

-----------------------------------------
# Start recording here

# Start off in the home page of loony-workspace

# Open up the ComputeIndiaSalesByCity

# Run each code cell and show the result

# In order to run as a Spark job we need a Python script (.py) file

# At the time of this recording, downloading the file as a .py file was not working

# Go to Download (the down arrow icon) and select the .py option

# We get a success message but the file is not downloaded (we'll set up our own script)

--------------------------------------------
# At the end go to the Lakehouse view of loony_lakehouse

# Show that we have the new table 

india_sales_by_city

# Now delete the table so it does not already exist when we run this code as a Spark job

--------------------------------------------
# Show the contents of this file

compute_india_sales_by_city.py


# Now switch into the Home page of the Workspace

# Create a new Spark Job Definition 

India Sales by City

# Upload the PY file to the job and select the loony-lakehouse

# Save and run the job

# Show the message and then go to the Runs tab and refresh

# In a few moments the job run will show up

# Click through to the run and this will take you to the monitoring interface for the job run

# Initially when the job is queued i.e. not running yet you will see "Application ID is null"

# Hit refresh on this page and soon the job will start running

# You can see the "Run details" on the right

# Hit refresh periodically on this page and wait for the job to complete

----------------------------------------------------------------------------
# Once the job is complete click on

Resource(Preview)

# This gives you a preview of the resources used by this job on the Spark cluster

# Click on some portions of the chart where the blue and the orange lines are above 0

# Note below that you get information for the "Running executor core allocation details"

# Click on 

Logs

# Here select 

Latest stdout (should have our print statements)

Latest stderr (should be no errors)

# Click on 

Data

# Nothing shows up here because our Spark job works on tables and does use input or output files

# Go to 

Item snapshots

# This gives you the job definition of the job that you just ran

----------------------------------------------------------
# Now let's run the job again (it will fail because the Delta table already exists)

# Click on the "India Sales by City" job definition on the left

# Click on Run

# Go to the "Runs" tab and hit refresh

# Should see a second run of the job

# Click through to the second run and hit "Refresh" and watch the job here till it completes

# The job will fail

# Click on "Logs" and go to "Latest sdterr"

# Notice that the exception says the table already exists

# Click on "Monitor Run Series"

# Note that there were 2 runs in the last 30 days

# You can see the "Duration time distribution" and "Executors execution distribution"

------------------------------------------------------

# Go back to the application run and click on "Spark History Server"

# Click on the link and show the Spark UI (please note that this UI is Spark specific and not a Fabric UI)

# There are many tabs here - exploring these are beyond the scope of this course and the certification

# Click on "Graph (Preview)"

# You can see the Stages into which the job is split (Each job is divided into one or more stages, which are groups of tasks that are executed in parallel. A stage corresponds to a unit of work that can be executed without shuffling data across the cluster.)

----------------------------------------------------

# It is possible to schedule jobs to run at periodic intervals as well (we'll not actually do this we will just see the settings)

# Click on the job definition from the left

# Click on the "Settings" icon

# SElect the following tabs

Schedule

# Turn on schedule

# Click on the Repeat drop down and show the options

# The other options are clearly visible

# Select the next option

Retry

# turn it on and show the options

----------------------------------------------------














