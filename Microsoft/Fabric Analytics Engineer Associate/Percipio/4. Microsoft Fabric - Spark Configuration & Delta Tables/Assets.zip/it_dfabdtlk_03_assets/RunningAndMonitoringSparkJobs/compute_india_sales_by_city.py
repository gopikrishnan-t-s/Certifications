from pyspark.sql import SparkSession
from pyspark.conf import SparkConf
from pyspark.sql.functions import sum


if __name__ == "__main__":

    spark = (SparkSession
          .builder
          .appName("Compute India Sales by City")
          .getOrCreate()
    )
    
    spark_context = spark.sparkContext
    spark_context.setLogLevel("DEBUG")

    superstore_df = spark.table("global_superstore")
    print("Read in superstore data")

    selected_columns_df = superstore_df.select("OrderID", "Country", "City", "Sales")
    print("Selected few columns")

    filtered_rows_df = selected_columns_df.filter(superstore_df["Country"] == "India")

    print("Filtered records for India")

    grouped_df = filtered_rows_df.groupBy("City").agg(
        sum("Sales").alias("TotalSales")
    )
    print("Grouped sales by city")

    grouped_df.write.format("delta").saveAsTable("india_sales_by_city")
    print("Wrote out Delta table with result")


