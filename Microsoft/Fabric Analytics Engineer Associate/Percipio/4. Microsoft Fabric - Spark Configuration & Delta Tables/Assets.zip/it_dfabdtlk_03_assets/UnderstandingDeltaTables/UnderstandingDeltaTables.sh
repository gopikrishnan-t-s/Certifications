########################################
# d-10-UnderstandingDeltaTables
########################################

# Dataset:
# https://www.kaggle.com/datasets/azzayahia/phone-sales-dataset

####################################################################
##### NOTES:

# When you create a table in a Microsoft Fabric lakehouse, a delta table is defined in the metastore for the lakehouse and the data for the table is stored in the underlying Parquet files for the table.

# With most interactive tools in the Microsoft Fabric environment, the details of mapping the table definition in the metastore to the underlying files are abstracted. However, when working with Apache Spark in a lakehouse, you have greater control of the creation and management of delta tables.


####################################################################




# IMPORTANT
# Make sure that set the Workspace to use the default "Starter pool"

# Make this change behind the scenes using Spark Settings

# This is needed because the other pool takes too long to start up, the Starter pool node are always available

-------------------------------------------------
# Go to the loony_lakehouse in the workspace

# In the lakehouse explorer on the left under Files/ create a folder called phones/

# Upload the phone_sales.csv file to the Files/phones/folder


# In the workspace create a new notebook can call it

UnderstandingDeltaTables

# Add the loony_lakehouse as a resource

# Rest of the instructions in the notebook













