###################################
# d-09-ManagingSparkComputeCapacity
###################################

##########################################################
######## NOTES:

# Apache Spark is a distributed data processing framework that enables large-scale data analytics by coordinating work across multiple processing nodes in a cluster, known in Microsoft Fabric as a Spark pool. 

# A Spark pool consists of compute nodes that distribute data processing tasks. 

# A Spark pool contains two kinds of nodes:
# A head node in a Spark pool coordinates distributed processes through a driver program.
# The pool includes multiple worker nodes on which executor processes perform the actual data processing tasks.
# The Spark pool uses this distributed compute architecture to access and process data in a compatible data store - such as a data lakehouse based in OneLake.

# Starter Pool

# Fabric automatically sets up a starter pool of compute resources that you can use for Spark. This is what we have been using so far. When we use the pool this reduces the amount of time required to set up a session. Fabric only has to create the session, not bring the nodes online. Spark automatically scales the nodes alloted to you based on your resource consumption. You are only billed for what you use of the Spark Compute i.e like a serverless service, not like a VM
##########################################################


###############
# Starter Pools
###############

# Start off on the loony-workspace

# Go to Workspace Settings -> Data Engineering/Science -> Spark settings

# Observe that Fabric has already created a "Starter pool" that we can use to run our Spark workloads

# Click on the "Starter Pool" and show that you have the option to create new Spark pools as well

# You can also edit the StarterPool details 

# Click on the "Edit" icon in the "Pool details" card and show that this can be configured

# Change the values in the Autoscale and Executor sliders

# Discard the changes

###############################################################
##### NOTES

# Microsoft Fabric provides a starter pool in each workspace, enabling Spark jobs to be started and run quickly with minimal setup and configuration. You can configure the starter pool to optimize the nodes it contains in accordance with your specific workload needs or cost constraints.

# Additionally, you can create custom Spark pools with specific node configurations that support your particular data processing needs.

# Specific configuration settings for Spark pools include:

# Node Family: The type of virtual machines used for the Spark cluster nodes. In most cases, memory optimized nodes provide optimal performance.
# Autoscale: Whether or not to automatically provision nodes as needed, and if so, the initial and maximum number of nodes to be allocated to the pool.
# Dynamic allocation: Whether or not to dynamically allocate executor processes on the worker nodes based on data volumes.

###############################################################


# Click on the "High concurrency" and show that it is enabled

############################################################
###### NOTES:

# When you run a notebook in Microsoft Fabric, an Apache Spark session is started and is used to run the queries submitted as part of the notebook cell executions. With High Concurrency Mode enabled, there's no need to start new spark sessions every time to run a notebook. You can connect to an existing high concurrency session and use that. This will ensure that your code runs faster since it does not have to wait for a new Spark session to be created

############################################################



##################
# High Concurrency
##################

# From the loony-workspace, create a new notebook Notebook1

# Add the loony_lakehouse

# Click on the "Connect" drop down and show that there are 2 possible sessions, no session has been created yet

# Run the following cell of code:

df = spark.table("global_superstore")
display(df)

# Show that the "Connect" drop down now says "Standard session"

# Note the time taken to create the session (this is in the code cell)
# 10 seconds to create the session, 20 seconds to run the code (total 30 seconds)
# These are indicative, actual values in the recording may be different

# Now create another notebook Notebook2

# Add the loony_lakehouse

df = spark.table("global_superstore")
display(df)

# Run this line of code again - this too takes 30-odd seconds (this is an entirely new session)
# Note that this is another standard session


# Switch to Notebook1

# In that notebook, click on the Session button and create a high-concurrency session

# Re-run the same cell - it takes 30-odd seconds (the high-concurrency session is being created for the first time)

# Now go to HighConcurrency2 and connect to the same session (you can see that it says 1/5, 1 notebook already connected and it can support 5)

# Now when you run that cell, it is much quicker (9 seconds for the whole command, and the session did not have to be set up)


###############################
# Custom Pools and Environments
###############################


##########################################################
######### Notes

# Spark Environments

# The Spark open source ecosystem includes multiple versions of the Spark runtime, which determines the version of Apache Spark, Delta Lake, Python, and other core software components that are installed. Additionally, within a runtime you can install and use a wide selection of code libraries for common (and sometimes  specialized) tasks.

# In some cases, organizations may need to define multiple environments to support a diverse range of data processing tasks. Each environment defines a specific runtime version as well as the libraries that must be installed to perform specific operations. Data engineers and scientists can then select which environment they want to use with a Spark pool for a particular task.

##########################################################

# Start from, 

# Switch to the loony-workspace view and go back to the Spark Settings

# Click on Default Pool --> New Pool

# Name: LoonyPool

# Node size: Large

# Min and max nodes are 1 - 2

# MAke sure you Save the changes

# Save this and go to the Environment tab

# Toggle Set Default Environment and create a new environment 

LoonyEnvironment

# Go to Spark Compute --> Compute and make sure it uses LoonyPool

# Select all the compute options (there is just one option for each)

# IMPORTANT: Click on each drop down and show the options

Spark driver core

Spark driver memory

Spark executor core

Spark executor memory

# Driver is the master Spark node, Executor is the worker node


# Show that you can set the following configuration (click on each)
# (note the explanations on each page)

Public libraries 



# Show how you can add the following libraries

pandas

numpy

# IMPORTANT
# Remove the libraries (we will NOT explicitly add them)
# we don't install anything here because all the basic data science libraries are already installed without explicitly specifying them


######################################
######## NOTES

# I tried installing some arcane libraries from PyPI but the install does not work. After publishing the environment I cannot actually import modules which are available in those libraries. It just says module not found

# I spent several hours trying to set this demo up well but I don't think this demo works properly, this feature seems a little glitchy.

# I don't think this is a big deal because all the major data science libraries are available by default

##########################################

Custom libraries

Spark properties

Resources


# Save and publish this environment - this will take some time (wait till it is published took about 15 minutes)


--------------------------------------------------------

# Now create a new notebook NewEnvironmentTest

# In that, modify the environment used to be LoonyEnvironment ("Workspace default" drop down)

# Create a standard session and run this line of code (might take 5 minutes for the environment to start up and run this cell):

print("Hello")

# This should run successfully

# Now run - Show that these are available by default

import pandas
import numpy























