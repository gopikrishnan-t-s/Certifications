########################################
# d-11-TimeTravelWithDeltaTables
########################################


###########################################################################
####### NOTES

# In Microsoft Fabric Lakehouses, the automatic time travel period is set to a 7-day retention limit. This means that data versioning is maintained for up to 7 days, allowing you to query and access historical versions of data during this period. After 7 days, the older versions are automatically purged to manage storage size and performance.

# This time travel feature allows users to perform actions such as auditing, debugging, and historical analysis within the retention window, but for longer-term needs, regular backups are recommended.

###########################################################################

# In the workspace create a new notebook can call it

TimeTravelWithDeltaTables

# Add the loony_lakehouse as a resource

# Rest of the instructions in the notebook












