################################################################
03-SimplePipeline
################################################################

# Creating a Simple Data Pipeline with Email Notification

Click on the lakehouse: LoonyLakehouse -> Open Notebook -> New Notebook

Rename notebook to "DataCleaning"
(Refer DataCleaning.ipynb)

Write code in the notebook (simple data transformation)
(Execute the code to make sure things work)

After notebook is executed -> go to LoonyLakehouse

Show that the LoanEligilibilityRecords_temp table is in there

# We will be using this notebook in the pipeline

-----------------------------------------------------

In the workspace "loony-workspace"

Click on "+New" -> Data Pipeline

name: transforming-data-pipeline

Click on "Template" (Just show)

Click on "Pipeline activity" -> "Notebook"

# First let's delete the temp table we have already created using a notebook

name: delete-table
description: Delete the table from the Lakehouse

Click on Advanced and show all options (hover over the help icons)

Click on Settings and show all options (hover over the help icons)


Click on +New next to Notebook

# This will open up a notebook in the warehouse

rename to: DeleteTable
(refer DeleteTable.ipynb)

Click on Lakehouse from the leftpane and select the lakehouse: LoonyLakehouse

Paste in the one code cell

---------
%%sql

DROP TABLE IF EXISTS LoanEligibilityRecords_Temp;
---------


IMPORTANT: DO NOT execute the code, we will execute as a part of the pipeline

--------------------------------------------------------
Click on "transforming-data-pipeline" from the left pane

Now select the activity: delete-table

Click on the "Settings" tab

Next to notebook click on "Refresh"

From the drop-down select the notebook "DeleteTable"

# Let's run the pipeline with a single activity

Save the pipeline

Click on "Run"

Show that the run succeeds at the bottom of the pane

Click on "Input" and "Output" and show the popup

Open up the LoonyLakehouse and show that the temporary table has disappeared


--------------------------------------------------------

# Now let's add more activities to the pipeline

Click on the arrow button and select: Notebook

name: clean-data
description: Data cleaning using a notebook

Click on Settings

workspace: loony-workspace
Notebook: DataCleaning


Save and run the pipeline
# Note how the activities are run one after another


Go to the LoonyLakehouse and show the LoanEligilibilityRecords_temp table

--------------------------------------------------------
# Adding a dataflow activity to the pipeline

Click on the arrow button and select: Dataflow


name: transform-data
description: Tranform data using dataflow

Click on Settings

workspace: loony-workspace
Dataflow: Click on +New

Rename dataflow to "Transform Loan Data"

In the dataflow -> Click on "Recent Sources" -> Select Lakehouse

LoonyLakehouse -> LoanEligibilityRecords_Temp (this table should be present)

Select the FLAG_EMAIL column -> Right-click -> Remove columns

Select destination for Dataflow -> "Warehouse"

Select LoonyWarehouse

Table name: LoanEligibilityRecordsFinal

Click on "Save Settings"

Select "Publish" to verify that the Dataflow is working
# Without publishing the dataflow was not showing up in the Data Pipeline list


Once the pipeline has been published 

Go to the LoonyWarehouse and show the table "LoanEligibilityRecordsFinal"


IMPORTANT: Delete this table

Click on "New SQL Query" and run:


DROP TABLE LoanEligibilityRecordsFinal

--------------------------------------------------------
# Wire up the dataflow in the pipeline

Go to the pipeline "transforming-data-pipeline"

Select "transform-data" dataflow activity

Go to Settings

# Select the dataflow

Dataflow: Transform Loan Data

--------------------------------------------------------
# Adding a send email activity to the pipeline


Click on arrow button of Dataflow and select: Outlook (email)

name: notify-succes
description: Notify when the pipeline has succeeded

Click on Advanced and show

Click on Settings

Click on "Sign in" -> "Allow Access" and sign in with your email account

To: cloud.user@loonycorn.com
Subject: transforming-data data pipeline succeeded

Body: The data pipeline has been completed successfully!

Click on "Add dynamic content" and select "Pipeline ID", "delete-table", "LoadTransformData", "removing-outliers"

# See screenshot-data-pipeline-email

Click on "Save" -> "Validate" -> "Run"

Observe the activities running at the bottom of the screen

Go to the LoonyWarehouse

Show the LoanEligibilityRecordsFinal table is present there

Go to the cloud.user@loonycorn.come email address

Show the email was received - click through and show the email

-------------------------------------------------
# In the workspace

Click on "loony-workspace" on the left

Click on the 3 dots next to transforming-data-pipeline

Click on "Recent runs" 

Click on any one of the previous run to see the details

On the top left click on "Back to the main view"

This will show you all the activities across the workspace

Click on the 3 dots next to "Transform Loan Data" -> "Historical runs"
(can see the runs for a specific activity in the pipeline)

-------------------------------------------------

Click on "loony-workspace" on the left

Click on the 3 dots next to transforming-data-pipeline

Click on "View item lineage"
(refer screenshot-item-lineage.png)


--------------------------------------------------------
# Send email on failure and completion of the pipeline as well

Right-click and copy the notify-succes email activity

Paste the activity and rename it to "notify-complete"

In the settings of the notify-complete activity change the subject line of the email to the following:

Subject: transforming-data data pipeline completed

Body: The data pipeline has been completed!

Click on "Add dynamic content" and select "Pipeline ID", "delete-table", "LoadTransformData", "removing-outliers"

Connect up notify-complete to the "complete" link of transform-data

--------------------
# Make a second copy

Paste the activity again (make a second copy) and rename it to "notify-failure"

In the settings of the notify-failure activity change the subject line of the email to the following:

Subject: transforming-data data pipeline failed

Body: The data pipeline had errors

Click on "Add dynamic content" and select "Pipeline ID", "delete-table", "LoadTransformData", "removing-outliers"

Connect up notify-failure to the "error" link of transform-data


--------------------

Now re-run the pipeline without making any changes

It will run through successfully

Check the cloud.user email

You will see 2 emails

# transforming-data data pipeline completed
# transforming-data data pipeline succeeded

--------------------
# Now we will cause the pipeline to fail (we will create a LoanEligibilityRecordsFinal with a schema that is incompatible with our dataflow)

Go to the LoonyWarehouse and the SQL editor

# Run these commands

DROP TABLE LoanEligibilityRecordsFinal;

CREATE TABLE LoanEligibilityRecordsFinal(
	DummyData VARCHAR(10)
);


Now go back to the transforming-data-pipeline pipeline

Now re-run the pipeline

The transform-data activity will fail

Click and show the failure message

Check the cloud.user email

You will see 2 emails

# transforming-data data pipeline completed
# transforming-data data pipeline failed




























