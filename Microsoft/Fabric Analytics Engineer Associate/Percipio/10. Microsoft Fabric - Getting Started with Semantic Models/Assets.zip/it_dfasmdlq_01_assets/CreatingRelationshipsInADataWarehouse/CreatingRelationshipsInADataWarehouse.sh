############################################
# d-01-CreatingRelationshipsInADataWarehouse
############################################

# Behind the scenes
# Show the ADLS container already set up

Resource group: loony-fabric
Storage account: loonyfabricstorage 

# Make sure you enable hierarchical namespaces

Container: loonyfabriccontainer

--------------------------------------------------------
# Start recording from here

# Start on the loonyfabricstorage page and show the details

# Click on Data storage -> Container on the left and show that we have one container

# Upload the telecom_data.csv file

# Click on the Storage Account
# Go to the Shared Access Signature on the left of the screen

# Hover over each of the "i" information icons

# Under allowed services select just

Blob

# Allowed resource types

Service
Container
Object

# Other settings are all default values

# Generate the SAS token and copy it over

----------------------------------------------
# Start in the MS Fabric workspace

# Switch to the "Data Warehouse" experience

# Access the loony-workspace - should already be set up 

# Should already have a warehouse inside it

LoonyWarehouse

# Run the following queries to create a table

CREATE TABLE TelecomMasterTable (
    CallID INT,
    CallerID INT,
    ReceiverID INT,
    PlanID INT,
    TimeID INT,
    CallDuration INT,
    CallCost DECIMAL(5, 2),
    CallerFirstName VARCHAR(50),
    CallerLastName VARCHAR(50),
    ReceiverFirstName VARCHAR(50),
    ReceiverLastName VARCHAR(50),
    PlanName VARCHAR(50),
    MonthlyCost DECIMAL(5, 2),
    Date DATE,
    Year INT,
    Quarter INT,
    Month INT,
    Week INT,
    Day INT
);



COPY INTO TelecomMasterTable
FROM 'https://loonyfabricstorage.blob.core.windows.net/loonyfabriccontainer/telecom_data.csv'
WITH (
    FIRSTROW=2,
    FILE_TYPE = 'CSV',
    CREDENTIAL=(IDENTITY= 'Shared Access Signature', SECRET='fill_in_secret')
)


# Show the data in the warehouse
# Then run these to create the fact and dimension tables:

CREATE TABLE FactCallRecords AS
SELECT
    CallID,
    CallerID,
    ReceiverID,
    PlanID,
    TimeID,
    CallDuration,
    CallCost
FROM
    TelecomMasterTable;


CREATE TABLE DimCustomers AS
SELECT DISTINCT
    CallerID AS CustomerID,
    CallerFirstName AS FirstName,
    CallerLastName AS LastName
FROM
    TelecomMasterTable;


CREATE TABLE DimPlans AS
SELECT DISTINCT
    PlanID,
    PlanName,
    MonthlyCost
FROM
    TelecomMasterTable;


CREATE TABLE DimTime AS
SELECT DISTINCT
    TimeID,
    Date,
    Year,
    Quarter,
    Month,
    Week,
    Day
FROM
    TelecomMasterTable;

# Now show all of these fact and dimension tables

# Click on the "Reporting" tab at the top of the pane

# Click on "New semantic model"

Telecom Model

# Select all the tables under "dbo" (including the master table)

# Open up the model in the workspace

# Click on "Open data model"

# Arrange the FactCallRecords in the center

# Arrange the Dim* tables around the fact

# Use the 3 dots to get rid of the the Master table since that is not needed in the semantic model

# IMPORTANT: Try to get all the tables in the same view so you do not have to scroll


# In that, draw the following relationships

------
# Fact.CallerID --> Dim.UserID

# Click on the drop-downs and show the options

Cross filter direction: Single

# Note that this relationship is active

---------------
# Fact.PlanID --> Dim.PlanID

Cross filter direction: Single

# Fact.TimeID --> Dim.TimeID

Cross filter direction: Single

-----
# Now click on New Report

# Cmd + S and save this report

Telecom Analysis

# Edit this report

# Create a table with CustomerID, Customer FirstName and LastName and sum of CallCosts (May have to add CustomerID, Sum of CallCosts, FirstName, LastName in this order then reorder the columns)

# IMPORTANT: Please check that the totals are actually different

# Create another table to have Year and sum of CallDuration

# Switch back to the model view and create a New Measure with this code

Average Call Duration = AVERAGE(FactCallRecords[CallDuration])

# Add this to the FactCallRecords table

# Now go back to the report - you will see this measure

# Add it as a card in that report


