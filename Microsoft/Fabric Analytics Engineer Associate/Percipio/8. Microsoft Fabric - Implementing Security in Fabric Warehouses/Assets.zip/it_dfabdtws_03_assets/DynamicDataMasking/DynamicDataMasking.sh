#########################
# d-07-DynamicDataMasking
#########################


----------------------------------------------------
---------------------------------------------------
# Fabric account: freddie@

# Switch to the Freddie account

# First let's change the permissions that contact@ has on the workspace

# Go to the loony-workspace -> Manage Access

# Change the privilege for contact@ to "Viewer"

# IMPORTANT NOTE
# Users with the Administrator, Member, or Contributor rights on the workspace will ALWAYS see unmasked data! Viewers will see masked data.

---------------------------------------------------



# Let's create two tables, both with the same masked data


CREATE TABLE MaskedEmployeesInfo_One (
    Name VARCHAR(100),
    Department VARCHAR(100),
    PhoneNumber VARCHAR(20) MASKED WITH (FUNCTION = 'partial(3, "XXX-XXXX", 0)'), -- custom string mask
    EmailID VARCHAR(100) MASKED WITH (FUNCTION = 'email()'),
    Salary INT MASKED WITH (FUNCTION = 'default()'),
    PerformanceScore FLOAT MASKED WITH (FUNCTION = 'random(1, 5)'),
    HomeAddress VARCHAR(200) MASKED WITH (FUNCTION = 'partial(0, "XXXX XXXX...", 0)')
);


# Insert some random data

INSERT INTO MaskedEmployeesInfo_One (Name, Department, PhoneNumber, EmailID, Salary, PerformanceScore, HomeAddress)
VALUES 
    ('John Doe', 'Sales', '123-456-7890', 'john.doe@example.com', 50000, 4.5, '123 Main St'),
    ('Jane Smith', 'Marketing', '987-654-3210', 'jane.smith@example.com', 60000, 4.8, '456 Elm St'),
    ('Bob Johnson', 'IT', '555-123-4567', 'bob.johnson@example.com', 70000, 4.9, '789 Oak St'),
    ('Maria Rodriguez', 'HR', '111-222-3333', 'maria.rodriguez@example.com', 55000, 4.6, '901 Maple St'),
    ('David Lee', 'Finance', '444-555-6666', 'david.lee@example.com', 65000, 4.7, '234 Pine St'),
    ('Emily Chen', 'Sales', '777-888-9999', 'emily.chen@example.com', 52000, 4.4, '567 Cedar St'),
    ('Kevin White', 'Marketing', '333-444-5555', 'kevin.white@example.com', 58000, 4.3, '890 Walnut St'),
    ('Sarah Taylor', 'IT', '666-777-8888', 'sarah.taylor@example.com', 72000, 4.95, '345 Spruce St'),
    ('Michael Davis', 'HR', '999-000-1111', 'michael.davis@example.com', 54000, 4.2, '678 Cherry St'),
    ('Lisa Nguyen', 'Finance', '222-333-4444', 'lisa.nguyen@example.com', 62000, 4.1, '901 Ash St');


# Now create a table where sensitive data is masked

CREATE TABLE MaskedEmployeesInfo_Two (
    Name VARCHAR(100),
    Department VARCHAR(100),
    PhoneNumber VARCHAR(20) MASKED WITH (FUNCTION = 'partial(3, "XXX-XXXX", 0)'), -- custom string mask
    EmailID VARCHAR(100) MASKED WITH (FUNCTION = 'email()'),
    Salary INT MASKED WITH (FUNCTION = 'default()'),
    PerformanceScore FLOAT MASKED WITH (FUNCTION = 'random(1, 5)'),
    HomeAddress VARCHAR(200) MASKED WITH (FUNCTION = 'partial(0, "XXXX XXXX...", 0)')
);

# Insert data into the masked table

INSERT INTO MaskedEmployeesInfo_Two (Name, Department, PhoneNumber, EmailID, Salary, PerformanceScore, HomeAddress)
VALUES 
    ('John Doe', 'Sales', '123-456-7890', 'john.doe@example.com', 50000, 4.5, '123 Main St'),
    ('Jane Smith', 'Marketing', '987-654-3210', 'jane.smith@example.com', 60000, 4.8, '456 Elm St'),
    ('Bob Johnson', 'IT', '555-123-4567', 'bob.johnson@example.com', 70000, 4.9, '789 Oak St'),
    ('Maria Rodriguez', 'HR', '111-222-3333', 'maria.rodriguez@example.com', 55000, 4.6, '901 Maple St'),
    ('David Lee', 'Finance', '444-555-6666', 'david.lee@example.com', 65000, 4.7, '234 Pine St'),
    ('Emily Chen', 'Sales', '777-888-9999', 'emily.chen@example.com', 52000, 4.4, '567 Cedar St'),
    ('Kevin White', 'Marketing', '333-444-5555', 'kevin.white@example.com', 58000, 4.3, '890 Walnut St'),
    ('Sarah Taylor', 'IT', '666-777-8888', 'sarah.taylor@example.com', 72000, 4.95, '345 Spruce St'),
    ('Michael Davis', 'HR', '999-000-1111', 'michael.davis@example.com', 54000, 4.2, '678 Cherry St'),
    ('Lisa Nguyen', 'Finance', '222-333-4444', 'lisa.nguyen@example.com', 62000, 4.1, '901 Ash St');

# Now as the admin user run these commands

SELECT * FROM MaskedEmployeesInfo_One;


SELECT * FROM MaskedEmployeesInfo_Two;

# All of the data should be visible unmasked! 
# This is because as admin users the data is always unmasked for us. This user has elevated privileges.



----------------------------------------------------
---------------------------------------------------
# Fabric account: contact@

# Switch to the Contact account


SELECT * FROM MaskedEmployeesInfo_One;

SELECT * FROM MaskedEmployeesInfo_Two;

# This data is masked based on the masking scheme that we have specified!

--------------

# This masking can be subverted

SELECT TOP (100) 
    [Name],
    [Department],
    [PhoneNumber],
    [EmailID],
    [Salary],
    [PerformanceScore]
    [Home Address],
    CASE 
        WHEN Salary BETWEEN 40000 AND 50000 THEN 'Low'
        WHEN Salary BETWEEN 50001 AND 60000 THEN 'Medium'
        WHEN Salary BETWEEN 60001 AND 70000 THEN 'High'
        ELSE 'Out of Range'
    END AS Salary_Bin
FROM [loony-warehouse].[dbo].[MaskedEmployeesInfo_One];


# Notice that you get results based on the salary column even though it is masked!

----------------------------------------------------
---------------------------------------------------
# Fabric account: freddie@

# Switch to the Freddie account

# Unmask the data on one table for contact@

GRANT UNMASK ON dbo.MaskedEmployeesInfo_One TO [contact@loonycorn.com];



----------------------------------------------------
---------------------------------------------------
# Fabric account: contact@

# Switch to the Contact account

SELECT * FROM MaskedEmployeesInfo_One;

# Should be able to see the data

SELECT * FROM MaskedEmployeesInfo_One;

# This data is still masked



----------------------------------------------------
---------------------------------------------------
# Fabric account: freddie@

# Switch to the Freddie account

# Go to the loony-workspace -> Manage Access

# Change the privilege for contact@ to "Contributor"



----------------------------------------------------
---------------------------------------------------
# Fabric account: contact@

# Switch to the Contact account

SELECT * FROM MaskedEmployeesInfo_One;

# This one was already unmasked

SELECT * FROM MaskedEmployeesInfo_One;

# This data is now also unmasked!


----------------------------------------------------
---------------------------------------------------
# Fabric account: freddie@

# Go to the loony-workspace -> Manage Access

# Change the privilege for contact@ back to "Viewer"



----------------------------------------------------
---------------------------------------------------
# Fabric account: contact@

# Switch to the Contact account

SELECT * FROM MaskedEmployeesInfo_One;

# This one is still unmasked

SELECT * FROM MaskedEmployeesInfo_One;

# This data is still unmasked.

# Not sure whether this is a behavior or a bug, but once a user has contributor access and was able to see the unmasked data, setting the user back to viewer access does not work















