################################
# d-13-ViewsStoredProceduresUDFs
################################


######################################################################

# This section is brief, as data warehouses don't have any special types of views
# MS Fabric Warehouses do not offer materialized or secure views
# You can create a view in two ways
# Open a new query and run this:

CREATE VIEW YangonSupermarketSales AS
SELECT *
FROM SupermarketSales
WHERE City = 'Yangon';

# This will create a new view YangonSupermarketSales
# Now we will do it with the UI
# Create a new query and run this:

SELECT *
FROM SupermarketSales
WHERE City = 'Naypyitaw'


# Now select the query and click on Save as view

NaypyitawSupermarketSales

# This will let you automatically create a view from your query

# Now run these two queries on the views:

SELECT * FROM YangonSupermarketSales

SELECT * FROM NaypyitawSupermarketSales




# Create a new query and run this:

CREATE FUNCTION dbo.GetTotalSalesByProductLine(@ProductLine VARCHAR(50))
RETURNS DECIMAL(18, 2)  -- Scalar value (Total Sales) with 2 decimal places
AS
BEGIN
    DECLARE @TotalSales DECIMAL(18, 2);

    SELECT 
        @TotalSales = SUM(Total)
    FROM 
        SupermarketSales
    WHERE 
        ProductLine = @ProductLine;

    RETURN @TotalSales;
END;

# You will get an error because Fabric does not support scalar valued functions!



------------------------------------

# Rewrite to be a Table-valued Function


CREATE FUNCTION dbo.GetTotalSalesByProductLine(@ProductLine VARCHAR(50))
RETURNS TABLE
AS
RETURN 
(
    SELECT 
        ProductLine, SUM(Total) AS TotalSales
    FROM 
        SupermarketSales
    WHERE 
        ProductLine = @ProductLine
    GROUP BY
        ProductLine
);


# In the Explorer, go to dbo and select Functions

# Note that our function is in here!

# Invoke the UDFs

SELECT * FROM dbo.GetTotalSalesByProductLine('Health and beauty');

SELECT * FROM dbo.GetTotalSalesByProductLine('Sports and travel');

# This will give you the total sales for the product line specified



--------------------------

# Open the loony-warehouse explorer

# In the Explorer, expand the "sys" schema

# Expand the stored procedures section

# This will contain a very large number of stored procedures

# IMPORTANT: Expand the pane and show

# All of these are prefixed with sp or xp

# Create a New SQL Query and run this:

EXEC sys.sp_tables

# This will list all the tables in our LoonyWarehouse


# Now we will create our own Stored Procedure

# Run the following code:

CREATE PROCEDURE FilterSupermarketSales
    @ProductLine VARCHAR(50),
    @City VARCHAR(50),
    @MinUnitPrice DECIMAL(10, 2)
AS
BEGIN
    SELECT
        *
    FROM
        SupermarketSales
    WHERE
        ProductLine = @ProductLine
        AND City = @City
        AND UnitPrice >= @MinUnitPrice;
END;

# This will filter the SupermarketSales table on ProductLine, City, and UnitPrice

# In the Explorer, go to dbo and select Stored Procedures

# Now we can see our FilterSupermarketSales procedure

# Run each of these queries:

EXEC dbo.FilterSupermarketSales @City = "Yangon", @ProductLine = "Health and beauty", @MinUnitPrice = 80

EXEC dbo.FilterSupermarketSales @City = "Mandalay", @ProductLine = "Food and beverages", @MinUnitPrice = 50

# We can perform filtering using this function now



####################################################
# Dynamic SQL

####################################################

# This is a T-SQL alternative to stored procedures

# This lets us construct SQL queries as strings, and we can embed values into strings

# First we will define a simple T-SQL query:

# Paste all 3 statements and run them in one go

DECLARE @stmt NVARCHAR(MAX);

SET @stmt = 'SELECT * FROM SupermarketSales';

EXEC sp_executesql @stmt

# This will give us all the rows in the SupermarketSales table

# Run this using EXEC

EXEC('SELECT * FROM SupermarketSales')

# Again this will work, but this is unsafe when we have parameters

-----------------------------------

# Now we will construct a dynamic SQL query with a parameter
# Run the following code:

DECLARE @ProductLineValue VARCHAR(50) = 'Health and beauty';
DECLARE @sql NVARCHAR(MAX);

-- Construct the SQL query dynamically
SET @sql = 'SELECT InvoiceID, ProductLine, Total, SaleDate 
            FROM SupermarketSales 
            WHERE ProductLine = @ProductLine';

-- Execute the SQL dynamically using sp_executesql to prevent SQL injection
EXEC sp_executesql @sql, N'@ProductLine NVARCHAR(50)', @ProductLineValue;

# This will output all rows where ProductLine is Health and beauty



-------------------------------------

# And here is how you would write this using EXEC (the unsafe way)


DECLARE @ProductLine VARCHAR(50) = 'Health and beauty';
DECLARE @sql NVARCHAR(MAX);

-- Construct the dynamic SQL query
SET @sql = 'SELECT * FROM SupermarketSales WHERE ProductLine = ''' + @ProductLine + '''';

-- Execute the SQL string
EXEC(@sql);


# And show we get the same result

























