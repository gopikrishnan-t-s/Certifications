#####################################
# d-09-GrantingObjectLevelPermissions
#####################################


------------------------------------------------------------
------------------------------------------------------------
# Fabric account: freddie@


# Start in Fabric and go to LoonyWorkspace

# Click on Manage Access 

# IMPORTANT: Show that we are currently the Admin of the workspace, we have full permissions on the workspace

# Specify contact@loony

# Show the drop-down for kind of access - choose

Viewer

# Click on Add


------------------------------------------------------------
------------------------------------------------------------
# Fabric account: contact@

# Now log into Fabric as contact@

# Go to Data Warehouse -> Click on Workspaces

# The loony-workspace should be listed

# Switch to the Query view
# Run the following queries

# A simple select - should work

SELECT 
	*
FROM 
    SupermarketSales
WHERE 
    Branch = 'A' AND ProductLine = 'Health and beauty';

# An insert - should not work 

INSERT INTO SupermarketSales VALUES (
    'INV001',
    'B',
    'New York',
    'Member',
    'Female',
    'Food and beverages',
    15.00,
    3,
    45.00,
    '2024-09-23',
    'Credit Card'
);

# Note the error!

# We had shared the workspace with "Viewer" so a viewer cannot make modifications to the content of the workspace by default

# NOTE
# Update and delete will not work as well


----------------------------------------------------
----------------------------------------------------
# Fabric account: freddie@

# Switch to the Freddie account

# Under "Manage Access" add contact@ with "Contributor" role (or if contact@ is listed on the list just change the access to "Contributor")


----------------------------------------------------
----------------------------------------------------
# Fabric account: contact@

# Switch to the Contact account

# Now run the insert - should work

INSERT INTO SupermarketSales VALUES (
    'INV001',
    'B',
    'New York',
    'Member',
    'Female',
    'Food and beverages',
    15.00,
    3,
    45.00,
    '2024-09-23',
    '10:30:00',
    'Credit Card'
);

# # Update - should work

UPDATE SupermarketSales
SET 
    Total = 60.00,
    Quantity = 4
WHERE 
    InvoiceID = 'INV001';


# Delete - should work

DELETE FROM SupermarketSales
WHERE 
    InvoiceID = 'INV001';


----------------------------------------------------
----------------------------------------------------
# Fabric account: freddie@

# Switch to the Freddie account

# These are specific DENY rules which will override the workspace permissions
DENY INSERT, UPDATE, DELETE ON SupermarketSales TO [contact@loonycorn.com];


----------------------------------------------------
----------------------------------------------------
# Fabric account: contact@

# Switch to the Contact account

# A simple select - should work

SELECT 
	*
FROM 
    SupermarketSales
WHERE 
    Branch = 'A' AND ProductLine = 'Health and beauty';


# Other operations should not work

INSERT INTO SupermarketSales VALUES (
    'INV001',
    'B',
    'New York',
    'Member',
    'Female',
    'Food and beverages',
    15.00,
    3,
    45.00,
    '2024-09-23',
    'Credit Card'
);

# Error
# The INSERT permission or external policy action 'Microsoft.Sql/Sqlservers/Databases/Schemas/Tables/Rows/Insert' was denied on the object 'SupermarketSales', database 'loony-warehouse', schema 'dbo'.

UPDATE SupermarketSales
SET 
    Total = 60.00,
    Quantity = 4
WHERE 
    InvoiceID = 'INV001';


# Error
# The UPDATE permission or external policy action 'Microsoft.Sql/Sqlservers/Databases/Schemas/Tables/Rows/Update' was denied on the object 'SupermarketSales', database 'loony-warehouse', schema 'dbo'.


DELETE FROM SupermarketSales
WHERE 
    InvoiceID = 'INV001';

# The DELETE permission or external policy action 'Microsoft.Sql/Sqlservers/Databases/Schemas/Tables/Rows/Delete' was denied on the object 'SupermarketSales', database 'loony-warehouse', schema 'dbo'.


----------------------------------------------------
----------------------------------------------------
# Fabric account: freddie@

# Switch to the Freddie account

# Grant permission just for INSERT 
GRANT INSERT ON SupermarketSales TO [contact@loonycorn.com];


----------------------------------------------------
----------------------------------------------------
# Fabric account: contact@

# Switch to the Contact account

# This should work!

INSERT INTO SupermarketSales VALUES (
    'INV001',
    'B',
    'New York',
    'Member',
    'Female',
    'Food and beverages',
    15.00,
    3,
    45.00,
    '2024-09-23',
    'Credit Card'
);

# This should NOT work

UPDATE SupermarketSales
SET 
    Total = 60.00,
    Quantity = 4
WHERE 
    InvoiceID = 'INV001';


----------------------------------------------------
----------------------------------------------------
# Fabric account: freddie@

# Switch to the Freddie account

# Can revoke the previous permission that we had GRANTed or DENYed

REVOKE UPDATE ON SupermarketSales FROM [contact@loonycorn.com];

# This will go back to the workspace level permissions - that of contributor so updates will be allowed

----------------------------------------------------
----------------------------------------------------
# Fabric account: contact@

# Switch to the Contact account

# This should work

UPDATE SupermarketSales
SET 
    Total = 60.00,
    Quantity = 4
WHERE 
    InvoiceID = 'INV001';

# This should NOT work

DELETE FROM SupermarketSales
WHERE 
    InvoiceID = 'INV001';



----------------------------------------------------
----------------------------------------------------
# Fabric account: freddie@

# Switch to the Freddie account

# Permissions to execute stored procedures

# Create simple procedure

CREATE PROCEDURE GetSalesByBranchAndDate
    @Branch VARCHAR(50),
    @StartDate DATE,
    @EndDate DATE
AS
BEGIN
    -- Select sales data for the given branch and date range
    SELECT 
        *
    FROM 
        SupermarketSales
    WHERE 
        Branch = @Branch
        AND SaleDate BETWEEN @StartDate AND @EndDate
    ORDER BY 
        SaleDate;
END;


# Check that it works

EXEC GetSalesByBranchAndDate 
    @Branch = 'A', 
    @StartDate = '2019-02-01', 
    @EndDate = '2019-02-23';


# Deny SELECT access to the table

DENY SELECT ON SupermarketSales TO [contact@loonycorn.com];

# Allow access to the stored procedure
GRANT EXECUTE on GetSalesByBranchAndDate to [contact@loonycorn.com];


----------------------------------------------------
----------------------------------------------------
# Fabric account: contact@

# Switch to the Contact account

# This should give "permission denied"
SELECT * FROM SupermarketSales;


# This should work
EXEC GetSalesByBranchAndDate 
    @Branch = 'A', 
    @StartDate = '2019-02-01', 
    @EndDate = '2019-02-23';







