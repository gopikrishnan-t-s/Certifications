################################
# d-06-ColumnAndRowLevelSecurity
################################



####################################################
# Column-level security
####################################################

----------------------------------------------------
----------------------------------------------------
# Fabric account: freddie@

# Switch to the Freddie account

REVOKE SELECT, INSERT, UPDATE, DELETE ON SupermarketSales FROM [contact@loonycorn.com];

# This will set the permission for contact@ back to workspace level permissions. Specific grants will be revoked

# contact@ will be able to read and write data



----------------------------------------------------
----------------------------------------------------
# Fabric account: contact@

# Switch to the Contact account

SELECT 
	*
FROM 
    SupermarketSales

# This should work just fine


----------------------------------------------------
----------------------------------------------------
# Fabric account: freddie@

# Switch to the Freddie account

# Deny access to explicit columns

DENY SELECT ON SupermarketSales(InvoiceID, CustomerType, Payment) TO [contact@loonycorn.com];


----------------------------------------------------
----------------------------------------------------
# Fabric account: contact@

# Switch to the Contact account

SELECT 
	*
FROM 
    SupermarketSales

# Error
# Started running query at line 1
# The SELECT permission was denied on the column 'InvoiceID' of the object 'SupermarketSales', database 'loony-warehouse', schema 'dbo'.
# Msg 230, Level 14, State 1, Code line 1
# The SELECT permission was denied on the column 'CustomerType' of the object 'SupermarketSales', database 'loony-warehouse', schema 'dbo'.
# Msg 230, Level 14, State 1, Code line 1
# The SELECT permission was denied on the column 'Payment' of the object 'SupermarketSales', database 'loony-warehouse', schema 'dbo'.
# Msg 230, Level 14, State 1, Code line 1

# Note that this operation is not permitted because the user does not have access to certain columns in the table

# Open up the Explorer pane on the left

# Expand the columns in SupermarketSales and show that Contact can see what columns are available in the table

# Can query on columns that are allowed

SELECT 
    Branch, 
    City, 
    Gender, 
    ProductLine, 
    UnitPrice, 
    Quantity, 
    Total, 
    SaleDate
FROM 
    SupermarketSales;

# This should work


----------------------------------------------------
-----------------------------------------------
# Fabric account: freddie@

# Switch to the Freddie account

# Another way to set up column-level security (allow columns rather than deny columns)

DENY SELECT ON SupermarketSales TO [contact@loonycorn.com];

# Now allow access to just selected columns

GRANT SELECT ON SupermarketSales(InvoiceID, Branch, City, Total, SaleDate) TO [contact@loonycorn.com];


----------------------------------------------------
----------------------------------------------------
# Fabric account: contact@

# Switch to the Contact account

# Run this - this will give us the same "Permission denied" error
SELECT 
    *
FROM 
    SupermarketSales;

# This will work

SELECT 
    Branch, City, Total, SaleDate
FROM 
    SupermarketSales;


--------------------------------------------------------------------------
--------------------------------------------------------------------------

# Now let's set up row-level security

----------------------------------------------------
----------------------------------------------------
# Fabric account: freddie@

# Switch to the Freddie account

REVOKE SELECT, INSERT, UPDATE, DELETE ON SupermarketSales FROM [contact@loonycorn.com];

# This will set the permission for contact@ back to workspace level permissions. Specific grants or denies will be revoked

# contact@ will be able to read and write data (as contact@ is a contributor)

----------------------------------------------------
----------------------------------------------------
# Fabric account: contact@

# Switch to the Contact account

SELECT 
    *
FROM 
    SupermarketSales;

# Note that contact@ can view all ProductLines - scroll accordingly and show

# Should work - insert, update, and delete will also work, can try for yourselves


----------------------------------------------------
---------------------------------------------------
# Fabric account: freddie@

# Switch to the Freddie account

# Security policies are usually set up in their own schema. Our table is in the default "dbo" schema, we will set up a new schema called "security" for our row-level security policy

CREATE SCHEMA security;


# Create a security predicate
CREATE FUNCTION security.SalesPredicate(@ProductLine VARCHAR(50))
RETURNS TABLE
WITH SCHEMABINDING
AS
RETURN 
    SELECT 1 AS accessResult
    WHERE 
        -- Allow access to all users except 'contact@loonycorn.com'
        USER_NAME() <> 'contact@loonycorn.com'
        -- Allow 'contact@loonycorn.com' to access 'Health and beauty' products only
        OR @ProductLine = 'Health and beauty';
        



CREATE SECURITY POLICY security.SupermarketSalesSecurityPolicy
ADD FILTER PREDICATE security.SalesPredicate(ProductLine)
ON dbo.SupermarketSales
WITH (STATE = ON);


----------------------------------------------------
----------------------------------------------------
# Fabric account: contact@

# Switch to the Contact account

SELECT 
    *
FROM 
    SupermarketSales;

# Note that you can only see the products for health and beauty!

# Now contact@ cannot access other records even with explicit filters

SELECT 
    *
FROM 
    SupermarketSales
WHERE 
    ProductLine = 'Fashion accessories'

# This will return nothing

---------------
# Can only update rows for Health and beauty

# Run this
SELECT 
    AVG(UnitPrice)
FROM 
    SupermarketSales;

# Average price is around $53 (might be a little different)

# Now let's incrase the unit price by 10%

UPDATE SupermarketSales
SET UnitPrice = UnitPrice * 1.10,  -- Increase price by 10%
    Total = UnitPrice * Quantity   -- Recalculate total based on new price
WHERE ProductLine = 'Health and beauty';

# Run this again

SELECT 
    AVG(UnitPrice)
FROM 
    SupermarketSales;

# Now the average price should be around $58!

# Now try to increase the unit price for fashion accessories

UPDATE SupermarketSales
SET UnitPrice = UnitPrice * 1.10,  -- Increase price by 10%
    Total = UnitPrice * Quantity   -- Recalculate total based on new price
WHERE ProductLine = 'Fashion accessories';

# Note that it says (0 records affected), no records are updated


-------------
# Can update rows that then end up being filtered e.g you update the productline to something other than "Health and beauty" and this will end up being filtered out i.e. no longer available to contact@. This is possible because contact@ is updating records that are part of records that are visible to them. After updation they become inaccessible

# Run this command
SELECT 
    COUNT(*)
FROM 
    SupermarketSales;

# You will get a certain number of records, in my case this was 206

# Select records with this invoice ID

SELECT * FROM SupermarketSales 
WHERE InvoiceID = '448-81-5016';

# In my case this was 2 records, you should have at least 1

# Now run the update (change the row that was originally visible to a different product line)

UPDATE SupermarketSales
SET ProductLine = 'Fashion accessories'
WHERE InvoiceID = '448-81-5016';

# This should update 2 records

# Now run

SELECT 
    COUNT(*)
FROM 
    SupermarketSales;

# Should be 2 less, the updated records are no longer visible!

--------------

# NOTE that the contact@ user can similarly delete rows from "Health and beauty" but obviously cannot delete rows from other ProductLines




----------------------------------------------------
---------------------------------------------------
# Fabric account: freddie@

# Switch to the Freddie account

# Let's change our security policy to allow contact@ access to both "Health and beauty" and "Fashion accessories"

# Drop the existing policy
DROP SECURITY POLICY security.SupermarketSalesSecurityPolicy;


# Modify the security predicate to allow contact@ access to "Fashion accessories" and "Health and beauty"

ALTER FUNCTION security.SalesPredicate(@ProductLine VARCHAR(50))
RETURNS TABLE
WITH SCHEMABINDING
AS
RETURN 
    SELECT 1 AS accessResult
    WHERE 
        -- Allow access to all users except 'contact@loonycorn.com'
        USER_NAME() <> 'contact@loonycorn.com'
        -- Allow 'contact@loonycorn.com' to access 'Health and beauty' products
        OR @ProductLine = 'Health and beauty'
        -- Allow 'contact@loonycorn.com' to access 'Fashion accessories' products as well
        OR @ProductLine = 'Fashion accessories';


# Recreate the security policy

CREATE SECURITY POLICY security.SupermarketSalesSecurityPolicy
ADD FILTER PREDICATE security.SalesPredicate(ProductLine)
ON dbo.SupermarketSales
WITH (STATE = ON);

----------------------------------------------------
---------------------------------------------------
# Fabric account: contact@

# Switch to the Contact account


SELECT * FROM SupermarketSales;

# Scroll and show that you have both ProductLines - "Fashion accessories" and "Health and beauty"@


----------------------------------------------------
---------------------------------------------------
# Fabric account: freddie@

# Switch to the Freddie account

# Let's just clean up before the next demo

# Drop the existing policy
DROP SECURITY POLICY security.SupermarketSalesSecurityPolicy;

# Drop the security predicate
DROP FUNCTION security.SalesPredicate;
































