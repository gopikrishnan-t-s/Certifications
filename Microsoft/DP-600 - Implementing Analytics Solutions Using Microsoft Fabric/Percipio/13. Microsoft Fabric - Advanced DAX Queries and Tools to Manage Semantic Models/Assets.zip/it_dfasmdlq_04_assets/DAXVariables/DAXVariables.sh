###################
# d-10-DAXVariables
###################

# Let us use variables for DAX

EVALUATE
VAR FilteredCustomers = 
    FILTER(
        'bank_account_customers',
        'bank_account_customers'[Marital_Status] = "Married"
    )
    
RETURN FilteredCustomers

# This is our first step
# Now modify the code to be this and run

EVALUATE

VAR FilteredCustomers = 
    FILTER(
        'bank_account_customers',
        'bank_account_customers'[Marital_Status] = "Married"
    )
   
VAR TotalBalance = 
    SUMX(FilteredCustomers, 'bank_account_customers'[Outstanding_Balance])
    
RETURN {TotalBalance}

# This tells us that the total amount owed to the bank by Married people is almost 500K. We use the SUMX here rather than SUM, so we can see how we can reference DAX variables in other queries

# Now modify the code to include this:

EVALUATE

VAR FilteredCustomers = 
    FILTER(
        'bank_account_customers',
        'bank_account_customers'[Marital_Status] = "Married"
    )
   
VAR TotalBalance = 
    SUMX(FilteredCustomers, 'bank_account_customers'[Outstanding_Balance])
    
VAR CustomerCount = 
    COUNTROWS(FilteredCustomers)
    
RETURN {CustomerCount}


# This now tells us that there are a total of 35 married customers
# Now replace with this

EVALUATE

VAR FilteredCustomers = 
    FILTER(
        'bank_account_customers',
        'bank_account_customers'[Marital_Status] = "Married"
    )
   
VAR TotalBalance = 
    SUMX(FilteredCustomers, 'bank_account_customers'[Outstanding_Balance])
    
VAR CustomerCount = 
    COUNTROWS(FilteredCustomers)
    
    
VAR AverageBalance = 
    DIVIDE(TotalBalance, CustomerCount)

RETURN {AverageBalance}

# This tells us that the Average account balance of married people is  14K USD
