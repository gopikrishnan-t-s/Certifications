##############################
# d-12-WindowingFunctionsInDAX
##############################

# Open Fabric and go to the DAXLakehouse
# Upload the TSLA.csv file to that lakehouse
# Create a new table tsla_share_price from the file
# Go to the DAXSemanticModel -> Edit Tables ->  add this table to the model

# Go to DAX Editor and click on Connect on the top right

# Reconnect to the DAXSemanticModel and show that both tables are now visible


# We will now use windowing functions, which are useful in time-series data
# They can be used to compute moving averages, cumulative sums and other values in time-series data


# This is a manual, systematic way of calculating a moving average for 3-days for TSLA share
# Since you’re using a dynamic, row-by-row 3-day window, AVERAGEX is required here to ensure that it calculates the average for the filtered set of rows for each CurrentDate.

EVALUATE
ADDCOLUMNS(
    tsla_share_price,
    "3-Day Moving Average",
    VAR CurrentDate = tsla_share_price[Date]
    VAR FilteredTable = 
        FILTER(
            tsla_share_price,
            tsla_share_price[Date] <= CurrentDate &&
            tsla_share_price[Date] >= CurrentDate - 2
        )
    RETURN
        AVERAGEX(
            FilteredTable,
            tsla_share_price[Close]
        )
)

# This uses the WINDOW function for calculating the same moving average
# -2, REL, 0, REL:

# This specifies the range of the window.
# -2, REL indicates the starting point of the window, which is two rows before the current row (relative to the current row).
# 0, REL indicates the endpoint of the window, which is the current row itself.
# Together, this range means the WINDOW function will consider the current row and the previous two rows, effectively creating a 3-day window.
# SUMMARIZE(ALL(tsla_share_price), tsla_share_price[Date], tsla_share_price[Close]):

# This creates a summarized table with all unique dates and Close prices from the tsla_share_price table, ignoring any existing filters due to ALL.
# By using SUMMARIZE, the query provides a set of rows that WINDOW can use to calculate the moving average across the 3-day window.

# KEEP:

# When you specify KEEP, DAX respects any filters that are already applied to the data. This means that only the rows that meet the current filter conditions will be included in the window.
# For instance, if there’s a filter on tsla_share_price restricting data to a specific year, KEEP will ensure that only dates within that year are considered in the window.
# Use Case: KEEP is useful when you want the WINDOW to reflect any existing filters (e.g., only considering a subset of data within a particular time frame).
# REMOVEFILTERS (implicit alternative):

# If you omit KEEP, DAX will ignore any current filters on the table within the window, effectively applying REMOVEFILTERS.


EVALUATE
ADDCOLUMNS(
    tsla_share_price,
    "3-Day Moving Average",
    AVERAGEX(
        WINDOW(
            -2, REL, 0, REL,
            SUMMARIZE(
                ALL(tsla_share_price),
                tsla_share_price[Date],
                tsla_share_price[Close]
            ),
            ORDERBY(tsla_share_price[Date]),
            KEEP
        ),
        tsla_share_price[Close]
    )
)


# Cumulative sum of volume traded
# 0, ABS (Starting Point):

# 0 is the starting point of the window.
# ABS (absolute) specifies that this starting point is not relative to the current row but refers to a fixed position in the dataset, typically the first row of the entire table or group in the query.
# 0, REL (Ending Point):

# 0 specifies the ending point of the window.
# REL (relative) makes this point relative to the current row being evaluated.
# With 0, REL, the ending point will always be the current row in the context of the iteration.

EVALUATE
ADDCOLUMNS(
    tsla_share_price,
    "Cumulative Volume",
    SUMX(
        WINDOW(
            0, ABS, 0, REL,
            SUMMARIZE(
                ALL(tsla_share_price),
                tsla_share_price[Date],
                tsla_share_price[Volume]
            ),
            ORDERBY(tsla_share_price[Date]),
            KEEP
        ),
        tsla_share_price[Volume]
    )
)


# A rolling min of Low for the past 7 days

EVALUATE
ADDCOLUMNS(
    tsla_share_price,
    "7-Day Rolling Min of Low",
    MINX(
        WINDOW(
            -6, REL, 0, REL,
            SUMMARIZE(
                ALL(tsla_share_price),
                tsla_share_price[Date],
                tsla_share_price[Low]
            ),
            ORDERBY(tsla_share_price[Date]),
            KEEP
        ),
        tsla_share_price[Low]
    )
)
