###########################
# d-11-InformationFunctions
###########################

# Information functions are those that give you basic metadata and info about columns, tables, and environments
# For instance, here we are viewing the rows without any Type_Loan in DAX

EVALUATE
FILTER(
    bank_account_customers,
    ISBLANK(bank_account_customers[Type_Loan])
)

# Here, we verify that all the values in Account_Balance are numbers
# You can scroll through and all the values for the last column are True

EVALUATE
ADDCOLUMNS(
    bank_account_customers,
    "Is_Account_Balance_Number", ISNUMBER(bank_account_customers[Account_Balance])
)

# Find the ration of current balance to outstanding balance

EVALUATE
ADDCOLUMNS(
    bank_account_customers,
    "Balance_Ratio", bank_account_customers[Account_Balance] / bank_account_customers[Outstanding_Balance]
)

# Note the many rows with infinity values

# Here, we perform a safe division of Outstanding_Balance by Account_Balance
# We need the error check because the Outstanding_Balance is 0 in many cases

EVALUATE
ADDCOLUMNS(
    bank_account_customers,
    "Balance_Ratio", IFERROR(bank_account_customers[Account_Balance] / bank_account_customers[Outstanding_Balance], 0)
)

# Now the rows have 0 values



# Here, we use CONTAINS to check for Retired individuals. If even one row has retired, then this returns true.

# The CONTAINS function itself returns a boolean value (TRUE or FALSE), not a table. Therefore, you cannot use CONTAINS directly within an EVALUATE statement, as EVALUATE expects a table expression.

# This should return true

EVALUATE
ROW(
    "Contains_Retired", 
    CONTAINS(
        bank_account_customers, 
        bank_account_customers[Employment_Status], 
        "Retired"
    )
)

# This should return false

EVALUATE
ROW(
    "Contains_Student", 
    CONTAINS(
        bank_account_customers, 
        bank_account_customers[Employment_Status], 
        "Student"
    )
)

