##############################
# d-09-WorkingWithDAXIterators
##############################

# We use iterators in DAX to perform row-by-row calculations across a table, allowing us to apply expressions that evaluate each row individually and then aggregate the results. This is especially useful when the calculation requires context from individual rows, such as summing values after applying a custom expression or conditional logic.

# Iterators operate on tables row by row

EVALUATE
FILTER(
    bank_account_customers,
    bank_account_customers[Credit_Score] > 700 &&
    bank_account_customers[Account_Balance] > 10000
)

# The filter function is also an iterator

-------------------------------

# Iterators are used when we want to perform operations over multiple columns

# SUM, AVERAGE etc operate on a single column, iterators operate on multiple columns

# Create a measure using the QueryBuilder

Total_Withdrawal_Amount

# DAX expression (note we operate on multiple columns)

SUMX(
    'bank_account_customers',
    'bank_account_customers'[Account_Balance] + 'bank_account_customers'[Overdraft_Limit]
)

# Update and run

# Show the result

# Add another column - Employment_Status

# Show the results grouped by Employment_Status
---------------------------------------------------------------------

# We have explored all these types of iterators for aggregations
# There are many iterators for all common aggregations - SUMX, AVERAGEX, MEDIANX etc.

# Let us now compute a median debt score

Customer_Median_Debt_Score 

# Formula

MEDIANX(
    FILTER(
        bank_account_customers,
        bank_account_customers[Account_Balance] > 10000
    ),
    bank_account_customers[Outstanding_Balance] * 0.7 + bank_account_customers[Total_Debit_Amount] * 0.3
)


# Update and run - should give you a single value

5800

# Drag the Marital_Status column to the table

# Show the Debt score for each marital status. Divorced should have the highest value

# You cannot use MEDIAN directly here instead of MEDIANX because MEDIAN is not designed to handle expressions or iterate over filtered tables. MEDIAN only works on a single column of values directly within the context of the table, without any additional row-by-row calculation.
# MEDIANX is required because it iterates over each row in the filtered table (where Account_Balance > 10000) and evaluates the custom expression bank_account_customers[Outstanding_Balance] * 0.7 + bank_account_customers[Total_Debit_Amount] * 0.3 for each row before calculating the median of those results.
# MEDIAN does not accept expressions or allow filtering. It only works with a single column reference and cannot apply complex calculations row by row.
















