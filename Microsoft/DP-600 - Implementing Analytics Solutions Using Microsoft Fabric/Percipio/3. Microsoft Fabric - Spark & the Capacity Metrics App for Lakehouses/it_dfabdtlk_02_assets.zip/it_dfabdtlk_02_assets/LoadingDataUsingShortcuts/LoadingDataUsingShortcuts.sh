################################
# d-03-LoadingDataUsingShortcuts
################################


############################################################
# ADLS
############################################################

# Start off in the Azure Portal and navigate to Storage Accounts

# Click on "Create a resource" -> "Storage Account"

# Choose the "loony-fabric" resource group (can create a new one if needed)

# Create a new storage account called "loonyfabricstorageadls"

# Can use the default East US region

# Primary service - hover on the help icon for this (IMPORTANT)

Azure Blob Storage or ADLS Gen2

# Primary workload - hover on the help icon for this (IMPORTANT)

Big Data Analytics

# Show the drop-down for redundancy -> we can stick with locally redundant storage

# Click on Next

# Show that hierarchical namespaces are enabled (this is required when we created shortcuts)

# (IMPORTANT) Hover over the help icon for hierarchical namespaces

# Click on "Review + Create" -> "Create"

# We've just accepted the defaults for all other options


# Go to the resource -> Click on Containers on the left

# Within that, navigate to Containers and create a loony-fabric-container


# Upload the supermarket_sales_small.csv file to that container
# This is a small file with just about 99 records - see that the size is 9KB

# Click on the "loonyfabricstorageadls" using the bookmarks on top


# Now click on the "Shared access signature" in the sidebar

# Hover over help icon for "Allowed services" -> leave as is

# Hover over help icon for "Allowed resource types" -> Choose all 3 (Service, Container, Object)

# Hover over help icon for "Allowed permissions" -> Choose "Read" and "List"
# In order to create Shortcuts we only need "Read" and "List" access on the target


# Click on "Generate SAS and connection string"

# Copy over the SAS token 

---------------------------------------------------------------

# Now switch to Fabric 

# Make sure you are in the Explorer view of the Fabric Lakehouse

# Click on 3 dots next to Files -> New shortcut

# Select ADLS Gen2 and specify this URL: 

https://loonyfabricstorageadls.dfs.core.windows.net

# This is just the storage account name with the rest a standard URL for the ADLS distributed file system

# Name the connection ADLSShortcutConnection and select SAS Token for authentication

# Give it the SAS token and select the container

# Click on "Next" and then click on "Create"

# In the Explorer view show that we have the loony-fabric-container

# Within this we have the supermarket_sales_small.csv file

# Click on the 3 dots next to the CSV file

# Click on the container and show that we have the 9KB small file

# IMPORTANT: Click on the file and show that we have around 99 records


# Then create a table supermarket_sales_adls from the CSV file

# Open and show the table

# Click on the 3 dots next to the table -> Properties

# Show that this is a managed table i.e. data has been loaded from our CSV in ADLS into this lakehouse table in Fabric. 


# Go to the SQL Analytics Endpoint and run the following query

SELECT COUNT(*) FROM dbo.supermarket_sales_adls

# There should be 99 records in this table

----------------------------------------------------------
# Now let us see that the CSV file actually references the file in ADLS and is not stored in Fabric

# Open up the supermarket_sales_small.csv file in Sublimetext

# Add the 15-20 records from supermarket_sales_extra.csv into supermarket_sales_small.csv - make sure you save the file

# IMPORTANT: supermarket_sales_small.csv should now have around 120 records

# Head over to the Azure container

# Upload the new supermarket_sales_small.csv to the container and overwrite the original contents

# Note that the new size of the file is around 11kb

--------------------------------------------

# Back to Fabric

# Select the 3 dots next to loony-fabric-container and select "Refresh"

# Note that the CSV file is now 11KB

# IMPORTANT: Click on the file and show that we have around 120 records


# Go to the SQL Analytics Endpoint and run the following query

SELECT COUNT(*) FROM dbo.supermarket_sales_adls

# There are still 99 records in this table - that is because this table was created using the data loaded in from the file contents as they existed previously.

# We can reload the data into this table

# Go back to the Lakehouse view

# Click on 3 dots -> Load to Tables -> Existing Table

# Choose supermarket_sales_adls 

# Select overwrite data


# Go to the SQL Analytics Endpoint and run the following query

SELECT COUNT(*) FROM dbo.supermarket_sales_adls

# We should now have around 120 records




##################################################
# S3
##################################################

# Start on the Home page of AWS

# Go to Services -> S3

# Create a new bucket loony-fabric-bucket-s3

# Choose all the default settings while creating a bucket

# Upload the supermarket_sales_s3.csv file to the bucket

# Show that the file has been successfully uploaded

# Click through to the file and show "Properties"

# Note the object URL (copy this and keep aside)

https://loony-fabric-bucket.s3.us-east-2.amazonaws.com/supermarket_sales_s3.csv


-----------------------------------------------------------------

# Now go into Services -> IAM and click through to Policies -> Create Policy

# Choose the service S3 and select all the permissions for 

List 
Read

# Note that to create a shortcut and read from the target you only need read and list permissions

# Now select all the Resources it offers

# Click through and name the policy MSFabricS3Policy

# Create the policy

# In the list of policies search for MSFabric

# Show that the policy has been created

-----------------------------------------------------

# Now click on the Users tab in IAM

# Create a new user loony-fabric-user 

# Attach policies directly and attach the newly created policy

MSFabricS3Policy

# After creating the user, click on the Security Credentials tab and create a new Access Key

# Specify the use case as Application running outside AWS, and give it a description "Access Key for MS Fabric"

# Copy over the "Access key" and the "Secret access key"

# Switch to MS Fabric and open the Lakehouse view

# Click the three-dots next to Files and add another shortcut

# Select AWS S3 and give it this URL (the bucket URL without the object)
# https://{bucket-name}.s3.{region}.amazonaws.com

https://loony-fabric-bucket.s3.us-east-2.amazonaws.com


# Name the connection S3ShortcutConnection and give it the Access Key

# Select the bucket and continue the process

# After creating the shortcut, show the new supermarket_sales_s3 file

# Click through and show the contents of this file.

# You can now use this file to create a new table as before

# Everything works exactly like the ADLS shortcut that we saw earlier






















