########################################
# d-09-MonitoringFabricComputeCapacity
########################################

# Go to this link:

https://learn.microsoft.com/en-us/fabric/enterprise/metrics-app-install?tabs=1st

# Show the process

# Follow the install steps there

# Sign in as Freddie and install the app

# Choose to connect to our own data and then get the Capacity ID in the following way

# MS Fabric Settings --> Admin Portal --> Capacity Settings --> Trial --> Click on the trial

# Now copy the capacity ID from the URL just after capacities/

# Fill in UTC offset of 5.5 and move on

# Scroll and show the others

# NOTE the timepoints are automatically populated and are for internal use

# Go through the remaining steps and sign in as Freddie

# It will take a minute to update the data

# Use the "Capacity name:" drop down to select the "Trial" capacity

# The charts should update

# We're currently viewing the capacity usage for Compute

------------------------------------------------------------

# Top-left multi-ribbon chart

# The multi metric ribbon chart provides an hourly view of your capacity's usage. 

# These are the options (click on each)

CU - Capacity Units (CU) processing time in seconds.

Duration - Processing time in seconds.

Operations - The number of operations that took place.

Users - The number of users that performed operations.

# Come back to the original view 

CU - Capacity Units (CU) processing time in seconds.

# Note below the Fabric items that were used in the last 14 days (includes our use of the lakehouse and the notebooks and jobs that we have run)

# Now click on one of the days in the "Multi metric ribbon chart"

# Note that the items at the bottom are filtered and shown only for that day

# The chart on the right also updates but we haven't looked at that yet

# Click somewhere outside on the chart so the filtering is removed

-----------------------------------------

# In the Items at the bottom, click on the drop down "Select items kind(s)"

# SElect the "Spark Job Definition" and see the usage only for that

# Go back and "Select All" to reset

------------------------------------------

# Now let's look at the chart on the top-right

# Utilization shows the % of CU utilized over time

# Click on the "logarithmic" scale, our very small usage is better viewed here

# Click on "Throttling" -> "logarithmic" scale

# There are 3 categories of Throttling (just click on each -> "logarithmic" scale)

# Click on "Overages" - does not show anything (we haven't borrowed future capacity)

# Click on "System events" nothing here (Displays pause and resume capacity events. For more information see Monitor a paused capacity. When the state of the capacity has remained unchanged for last 14 days, the table doesn't display any information.)


# Show the Storage tab as well

# These are self-explanatory



















