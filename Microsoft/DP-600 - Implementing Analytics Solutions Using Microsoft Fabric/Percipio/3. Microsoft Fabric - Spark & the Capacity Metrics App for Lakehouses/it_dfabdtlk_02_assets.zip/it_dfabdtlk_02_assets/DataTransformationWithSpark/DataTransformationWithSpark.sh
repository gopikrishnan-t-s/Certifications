#############################
# d-06-DataTransformationWithSpark
#############################

##########################################################
######## NOTES:

# Apache Spark is a distributed data processing framework that enables large-scale data analytics by coordinating work across multiple processing nodes in a cluster, known in Microsoft Fabric as a Spark pool. 

# Spark can run code written in a wide range of languages, including Java, Scala (a Java-based scripting language), Spark R, Spark SQL, and PySpark (a Spark-specific variant of Python). In practice, most data engineering and analytics workloads are accomplished using a combination of PySpark and Spark SQL.

# A Spark pool consists of compute nodes that distribute data processing tasks. The general architecture is shown in the following diagram.

##########################################################



# In this demo we will perform some basic Spark data analysis operations using Spark data frames

# Start in the workspace -> New -> Notebook

# Name the notebook

DataTransformationWithSpark


# Click on the PySpark drop down at the top of the page and show the options we have to write code in Apache Spark (Python, Scala, SQL, R)

# Rest of the instructions in the notebook
























