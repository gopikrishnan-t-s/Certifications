# Here we filter on those customers with more than 15K owed

EVALUATE
SELECTCOLUMNS(
    'bank_account_customers',
    "Account_Type", 'bank_account_customers'[Account_Type],
    "Gender", 'bank_account_customers'[Customer_Gender],
    "Marital_Status", 'bank_account_customers'[Marital_Status],
    "Account_Balance", 'bank_account_customers'[Account_Balance]
)

EVALUATE
SUMMARIZECOLUMNS(
    bank_account_customers[Account_Type],
    bank_account_customers[Customer_Gender],
    bank_account_customers[Marital_Status],
    bank_account_customers[Account_Balance],
)

# In summary, SUMMARIZECOLUMNS is used for aggregating and grouping data, while SELECTCOLUMNS is used for selecting and potentially renaming columns without changing the row-level detail of the original table.
# Aggregation:
# SUMMARIZECOLUMNS: Automatically aggregates data, grouping by the specified columns. It will return unique combinations of Account_Type, Customer_Gender, and Marital_Status, with an aggregated Account_Balance (typically a sum, but this can vary based on the data model).
# SELECTCOLUMNS: Does not perform any aggregation. It returns all rows from the original table, just selecting (and potentially renaming) the specified columns.
# Row count:
# SUMMARIZECOLUMNS: Will likely return fewer rows than the original table, as it groups data.
# SELECTCOLUMNS: Will return the same number of rows as the original table.

EVALUATE
SUMMARIZECOLUMNS(
    bank_account_customers[Customer_Gender],
    bank_account_customers[Employment_Status],
    bank_account_customers[Marital_Status],
    bank_account_customers[Account_Type],
    bank_account_customers[Type_Loan],
    bank_account_customers[Outstanding_Balance],
    bank_account_customers[Account_Balance],
    bank_account_customers[Credit_Score],
    KEEPFILTERS( FILTER( ALL( bank_account_customers[Outstanding_Balance] ), bank_account_customers[Outstanding_Balance] >= 15000 ))
)
ORDER BY 
    bank_account_customers[Outstanding_Balance] ASC,
    bank_account_customers[Account_Balance] ASC


# Here we filter on the customer being married and having a credit score of 700+

EVALUATE
SUMMARIZECOLUMNS(
    bank_account_customers[Account_Balance],
    bank_account_customers[Account_Type],
    bank_account_customers[Credit_Score],
    bank_account_customers[Employment_Status],
    bank_account_customers[Marital_Status],
    bank_account_customers[Monthly_Transactions],
    bank_account_customers[Outstanding_Balance],
    bank_account_customers[Overdraft_Limit],
    bank_account_customers[Total_Credit_Amount],
    bank_account_customers[Total_Debit_Amount],
    KEEPFILTERS( TREATAS( {"Married"}, bank_account_customers[Marital_Status] )),
    KEEPFILTERS( FILTER( ALL( bank_account_customers[Credit_Score] ), bank_account_customers[Credit_Score] >= 700 ))
)

# This will show you all the customers who are either Employed or Self-Employed

/* START QUERY BUILDER */
EVALUATE
SUMMARIZECOLUMNS(
    bank_account_customers[Account_Balance],
    bank_account_customers[Account_Type],
    bank_account_customers[Credit_Score],
    bank_account_customers[Customer_Gender],
    bank_account_customers[Employment_Status],
    bank_account_customers[Marital_Status],
    bank_account_customers[Monthly_Transactions],
    bank_account_customers[Outstanding_Balance],
    bank_account_customers[Overdraft_Limit],
    bank_account_customers[Total_Credit_Amount],
    bank_account_customers[Total_Debit_Amount],
    bank_account_customers[Type_Loan],
    bank_account_customers[Years_with_Bank],
    KEEPFILTERS( TREATAS( {"Self-Employed","Employed"}, bank_account_customers[Employment_Status] ))
)

------------------------------------------------
# Now we will experiment with Query Builder

# There are three panes - columns / measures (we will come back to measures), filters, and order

# Drag the entire table for columns to Columns/Measures

# Add a filter for Outstanding Amount >= 15000 and Credit_Score < 700

# Click on Update and run the query

# These are customers at high risk of default, potentially

-----------------------------------------------------------

# In the top pane, expand the Results dropdown
# There are many options for where the results are outputted
# Select File first and run the query
# Save it as a CSV and open that CSV file
# Next, select clipboard and run the query
# Paste the output into Excel
# Now finally, select Dynamic Excel and run the query
# This is the most interesting
# It opens up an Excel spreadsheet that is connected to the DAX Studio
# Remove the filters and rerun the query
# The Excel file will automatically update, and give us a warning before displaying the update

-----------------------------------------------------------
