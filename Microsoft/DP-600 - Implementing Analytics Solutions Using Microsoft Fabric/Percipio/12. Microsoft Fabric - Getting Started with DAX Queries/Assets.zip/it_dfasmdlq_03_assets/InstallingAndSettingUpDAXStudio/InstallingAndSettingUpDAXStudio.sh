######################################
# d-05-InstallingAndSettingUpDAXStudio
######################################

# NOTES:
# This is the start of a course on DAX
# We will start by installing DAX Studio and connecting to a Fabric lakehouse
# We will then run some simple queries and create measures using DAX Studi
# After that, we will use some complex DAX features, like iterators
# We will do all of this using DAX Studio

# Start with an empty workspace loony-workspace

# Start with the Lakehouse and Semantic Model already set up (since they know to do all this)

# Behind the scenes

# First, let us set up our lakehouse and semantic model

# Open up Fabric and create a new Lakehouse

DAXLakehouse

# Upload the Bank_Account_Customers.csv file to the lakehouse
# Create a new table from that file

bank_account_customers

# Show the contents of this table

# Now click on New Semantic Model

# Name this DAXSemanticModel and add our table

# Now we have set up our semantic model, and are ready to connect from DAX Studio

---------------------------------------------------------

# Start recording from here

# Switch to the Data Engineering experience

# Show the DAXLakehouse that we have set up

# Show the the file that we have uploaded and the table

# Show the DAXSemanticModel with our table

--------------------------------------------------------

# Open up a web browser and go to this URL: https://daxstudio.org/

# Download the installer file and go through the install process

# Open up DAX Studio after the install

# It will ask for a connection method - select Tabular Server

# Give it this URL: powerbi://api.powerbi.com/v1.0/myorg/loony-workspace (assuming your workspace is called loony-workspace)

# Expand the Advanced options and specify "Admin" for Roles
# If we do not do this, it does not understand that we are workspace admins

# Sign in as dora@loony (or whichever account you are using)

# Select the DAXSemanticModel from the lakehouses and warehouses option

# Now you should see bank_account_customers under metadata

# Explore the UI - go through Functions, DMV and other tabs

#################
### NOTES
# Metadata Tab: The Metadata tab displays the schema of the data model, including tables, columns, measures, and hierarchies available in the connected dataset, allowing you to easily explore and select data elements for queries. It provides a structured view, helping users understand the data model’s layout and content.

# Functions Tab: The Functions tab lists all available DAX functions, categorized by type (e.g., Time Intelligence, Text, Math), and provides a reference for function syntax and usage. This tab is a quick resource for finding the right DAX functions to use in queries and calculations.

# DMV Tab: The DMV (Dynamic Management Views) tab provides access to system views that expose model metadata and performance data, useful for advanced diagnostics and optimization. It enables users to retrieve information about the internal state of the model, such as memory usage, storage details, and query performance.
#################


# Note the Query Builder - this is a drag-and-drop UI to construct DAX queries

# We will explore this in a future demo
# For now, paste this query into the query editor:

EVALUATE
SUMMARIZECOLUMNS(
    bank_account_customers[Account_Balance],
    bank_account_customers[Account_Type],
    bank_account_customers[Credit_Score],
    bank_account_customers[Customer_Gender],
    bank_account_customers[Employment_Status],
    bank_account_customers[Marital_Status],
    bank_account_customers[Monthly_Transactions],
    bank_account_customers[Outstanding_Balance],
    bank_account_customers[Overdraft_Limit],
    bank_account_customers[Total_Credit_Amount],
    bank_account_customers[Total_Debit_Amount],
    bank_account_customers[Type_Loan],
    bank_account_customers[Years_with_Bank]
)

# Run the DAX - this will show us all the rows in our dataset
# This is the simplest DAX query

# Clear the editor view
-------------------------------------------------------------------
# We will now construct a similar query using the Query Builder

# Drag the entire bank_account_customers table into the Columns/Measures section

# Click on update and demonstrate the query

# Note that the Order By section has automatically been filled in

# The generated query is similar to our query

# Run this and show the result