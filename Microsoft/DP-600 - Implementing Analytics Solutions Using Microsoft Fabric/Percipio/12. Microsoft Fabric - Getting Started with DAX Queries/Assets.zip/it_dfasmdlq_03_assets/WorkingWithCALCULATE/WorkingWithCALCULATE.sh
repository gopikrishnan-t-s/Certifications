###########################
# d-08-WorkingWithCALCULATE
###########################

# In this demo, we will see how to define measures using the CALCULATE function
# This allows you to perform explicit filtering while defining the measure
# Explicit filtering is where you specify in the measure definition that it should perform some kind of filtering
# We will also use the FILTER and ALL functions with CALCULATE

# We will start with some basic measures using CALCULATE
# Start off with a blank Query Builder
# Click on New Measure and name it 

SelfEmployed_Account_Balance

# Add in this definition

CALCULATE(
    SUM(bank_account_customers[Account_Balance]),
    bank_account_customers[Employment_Status] = "Self-Employed"
)

# Click on update and show the creation of this measure - should look like this below

DEFINE
MEASURE bank_account_customers[SelfEmployed_Account_Balance] = CALCULATE(
    SUM(bank_account_customers[Account_Balance]),
    bank_account_customers[Employment_Status] = "Self-Employed"
)
EVALUATE
CALCULATETABLE(
    ROW(
    "SelfEmployed_Account_Balance", [SelfEmployed_Account_Balance]
    )
)

# Add the Employment_Status column to the measure, update

# The measure changes to this below


DEFINE
MEASURE bank_account_customers[SelfEmployed_Account_Balance] = CALCULATE(
    SUM(bank_account_customers[Account_Balance]),
    bank_account_customers[Employment_Status] = "Self-Employed"
)
EVALUATE
SUMMARIZECOLUMNS(
    bank_account_customers[Employment_Status],
    "SelfEmployed_Account_Balance", [SelfEmployed_Account_Balance]
)
ORDER BY 
    bank_account_customers[Employment_Status] ASC

# Note that we get the same value of the "SelfEmployed_Account_Balance" for each value of EMployment_Status

------------------------------------------------

# Now let us try this in Power BI

# Go to the DAXSemanticModel and add this measure to the table

SelfEmployed_Account_Balance

# Add in this definition

CALCULATE(
    SUM(bank_account_customers[Account_Balance]),
    bank_account_customers[Employment_Status] = "Self-Employed"
)

# Switch over to the "Customer Analysis" report tab

# IMPORTANT: Make sure you remove all the previous filters and clear existing tables

# Add a new table with

Employment_Status
SUM of Account_Balance 

# Note that there is implicit filtering and we see the SUM for each of the 4 employment_status types

# Now add the SelfEmployed_Account_Balance to the table columns

# It will show the same value for all 4

# Now to the same table add

Marital_Status

# This will now breakdown the total SelfEmployed_Account_Balance based on Marital_Status

----------------------------------------------------------------------------

# Back to DAX Studio

# Remove all the previous measures

# We will now see how to use the FILTER function along with calculate
# Create a New Measure 

Married_CheckingAccount_Balance

# Add this query:

CALCULATE(
    SUM(bank_account_customers[Outstanding_Balance]),
    FILTER(
        bank_account_customers,
        bank_account_customers[Marital_Status] = "Married" &&
        bank_account_customers[Account_Type] = "Checking"
    )
)

# This uses the FILTER function within CALCULATE to add multiple aggregations

# Now remove all of the columns and add the Employment_Status column in Query Builder

# Rerun the query 

# You now get the total checking account balance for married people grouped by Employment_Status.

# You should get results for Employeed and Self-Employeed

----------------------------------------------------------------------

# Now add another new measure called 

Total_Outstanding_Balance 

# Paste in this formula:

SUM(bank_account_customers[Outstanding_Balance])

# Update and create the measure

# Drag in the Account_Type column

# Show the outstanding balance by account type

# Now add another new measure called 

Grand_Total_Outstanding_Balance

# Paste in this formula:

CALCULATE(
    SUM(bank_account_customers[Outstanding_Balance]),
    ALL(bank_account_customers)
)

# This specifies that, whatever grouping is performed, the measure should only be measured for all of the rows in the bank_account_customers table

# We now have the following in the Column/Measures field
# - Account_type
# - Grand_Total_Outstanding_Balance
# - Total_Outstanding_Balance

# Clear the editor pane and click on Update

# The measure definition should look like this

DEFINE
MEASURE bank_account_customers[Grand_Total_Outstanding_Balance] = CALCULATE(
    SUM(bank_account_customers[Outstanding_Balance]),
    ALL(bank_account_customers)
)
MEASURE bank_account_customers[Total_Outstanding_Balance] = SUM(bank_account_customers[Outstanding_Balance])
EVALUATE
SUMMARIZECOLUMNS(
    bank_account_customers[Account_Type],
    "Grand_Total_Outstanding_Balance", [Grand_Total_Outstanding_Balance],
    "Total_Outstanding_Balance", [Total_Outstanding_Balance]
)
ORDER BY 
    bank_account_customers[Account_Type] ASC


# Here, for all the groups, GrandTotalOutstandingDebt still shows 560K, while TotalOutstandingDebt is dynamic
