########################################
# d-12-TheMedallionArchitecture
########################################

# Before you start recording delete all the previous tables and files from the Lakehouse

# We'll start off on a fresh slate

# Start off in the Lakehouse explorer view


# Click on the 3 dots next to Files -> New subfolder, name this

bronze

# Upload the following file into the "bronze" subfolder

Global_Superstore_Part1.csv

# This is our raw bronze layer where the original data is ingested i.e. uploaded

# Keep the lakehouse open on one tab

# Set up the notebook on a new tab

# We'll need to periodically reference the lakehouse so have it open

------------------------------------------------

# Now let's transform and load this data into the silver layer

# Go back to the workspace and create a new notebook

TransformAndLoadDataToSilverLayer

# Add the loony_lakehouse to the notebook

# Follow the instructions in the notebook


--------------------------------------------------
--------------------------------------------------
--------------------------------------------------
--------------------------------------------------
# Back from the notebook here


# Create a semantic model

# In the Lakehouse view

# Click on the SQL Analytics Endpoint

# Show that the default semantic model contains all tables (we cannot use this, we need to create a new one with only the gold tables)

# Go to Reporting -> New Semantic Model - call it

supermarket_gold

# Only select all the gold tables to include in this semantic model

# The model workspace should open up automatically

# If it does not, then go to the workspace -> click on "supermarket_gold"

# Click on "Open data model" at the top of the page

# IMPORTANT: Make sure you close all unnecessary sidebars on the right

# Place the fact table at the center

# Place the dimension tables around the fact table

# IMPORTANT
# Make sure that you can see all the tables on the screen (adjust the zoom accordingly)

------------------------------------------------

# Now let us set up the relationships

# dim_dates_gold -> fact_supermarket_gold

# Drag OrderDate (dim_dates_gold) -> OrderDate (fact_supermarket_gold)

Relationship: One to many

Cross-filter direction: Single

# Click on Save



# dim_products_gold -> fact_supermarket_gold

# Drag ProductID (dim_products_gold) -> ProductID (fact_supermarket_gold)

Relationship: One to many

Cross-filter direction: Single

# Click on Save

----------------------------------------

# dim_customers_gold -> fact_supermarket_gold

# Drag CustomerID (dim_customers_gold) -> CustomerID (fact_supermarket_gold)

Relationship: One to many

Cross-filter direction: Single

# Click on Save


----------------------------------------

# dim_orders_gold -> fact_supermarket_gold

# Drag OrderID (dim_orders_gold) -> OrderID (fact_supermarket_gold)

Relationship: One to many

Cross-filter direction: Single

# Click on Save

---------------------------------------

# Go back to the workspace

# Create a new Power BI report -> select the semantic model "supermarket_gold"

# This report will use the relationships in the semantic model (the 4 dimensions and 1 fact table will automatically be brought into the report)

# Close the "Filters" section

# Create 4 tables

Country and Sum of Profit

OrderMonth and Sum of Sales

OrderPriority and Average of ShippingCost

Category and Average ProfitMargin


# The relationships in the semantic model is what allow us to view the data in this manner





























































