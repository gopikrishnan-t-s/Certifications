##############################
# d-03-RunningTSQLQueriesOnAnalyticsEndpointInLakehouse
##############################

# In this demo we will create a lakehouse in the same workspace and create a delta table

-----------------------------------------------------------

# # Now please explain this really really quickly (since we had an entire path on this)


# Switch to the Synapse Data Engineering on the bottom left and create a lakehouse


loony_lakehouse

# In the Explorer, click on the three-dots for "Files" and choose "Upload" -> "Files"

# Then choose the supermarket_sales.csv file and upload that

# Show the file uploaded

# Now click on the three-dots for the CSV file

# Choose Load to Table

supermarket_sales_lh


# After it loads, click on the table and show the preview

# NOTE: The little triangular icon on the table, this indicates that this table is a Delta table

---------------------------------------------------------------

# Close the left pane

# Switch over to the SQL Analytics Endpoint

# Go to Query

# Right-click and rename the query to 

DataLakehouseQueries


# NOTE: All read queries will work!

# Filter the rows in the table

SELECT * 
FROM supermarket_sales_lh
WHERE CustomerType = 'Member';

# One more

SELECT 
    ProductLine, 
    SUM(Total) AS TotalSales
FROM 
    supermarket_sales_lh
GROUP BY 
    ProductLine
ORDER BY 
    TotalSales DESC;


# Try to create a table using T-SQL

CREATE TABLE [dbo].[Customers] (
    [CustomerID] INT,
    [FirstName] VARCHAR(50),
    [LastName] VARCHAR(50),
    [Email] VARCHAR(100),
    [PhoneNumber] VARCHAR(20),
    [Address] VARCHAR(255),
    [City] VARCHAR(50),
    [Country] VARCHAR(50),
    [RegistrationDate] DATE
);

# Note the error!

# The external policy action 'Microsoft.Sql/Sqlservers/Databases/Schemas/Tables/Create' was denied on the requested resource.
# Msg 368, Level 14, State 1, Code line 1


# However we can create Delta tables using Apache Spark (we've seen that in the previous learning path)

-----------------------------------------------------

# Try to insert data

INSERT INTO [dbo].[supermarket_sales_lh] 
    (InvoiceID, Branch, City, CustomerType, Gender, ProductLine, UnitPrice, Quantity, Total, [Date], Payment)
VALUES 
    ('INV10239', 'A', 'Mandalay', 'Member', 'Female', 'Health & Beauty', 25.50, 5, 127.50, '2024-09-21', 'Credit Card');

# Note the square brackets around [Date] since it is a reserved keywords. We're indicating to Fabric that these are actually identifiers

# Note the error!

# Data Manipulation Language (DML) statements are not supported for this table type in this version of SQL Server.

-----------------------------------------------

# Try to update records

UPDATE supermarket_sales_lh
SET Payment = 'Mobile Payment'
WHERE Payment = 'Credit card'
AND [Date] BETWEEN '2019-01-01' AND '2019-01-31';

# Error!

# Data Manipulation Language (DML) statements are not supported for this table type in this version of SQL Server.

-----------------------------------------------

# Try to delete records


DELETE supermarket_sales_lh
WHERE Payment = 'Credit card'
AND [Date] BETWEEN '2019-01-01' AND '2019-01-31';

# Error!

# Data Manipulation Language (DML) statements are not supported for this table type in this version of SQL Server.

#######################################################################

# Same transaction on lakehouse

BEGIN TRANSACTION;

BEGIN TRY
    -- Insert first record
    INSERT INTO [dbo].[supermarket_sales_lh] 
        (InvoiceID, Branch, City, CustomerType, Gender, ProductLine, UnitPrice, Quantity, Total, [Date], Payment)
    VALUES 
        ('INV10240', 'Z', 'New York', 'Normal', 'Male', 'Groceries', 15.99, 10, 159.90, '2024-09-21', 'Cash');

    -- Insert second record
    INSERT INTO [dbo].[SupermarketSales] 
        (InvoiceID, Branch, City, CustomerType, Gender, ProductLine, UnitPrice, Quantity, Total, [Date], Payment)
    VALUES 
        ('INV10241', 'Z', 'Los Angeles', 'Member', 'Female', 'Electronics', 99.99, 2, 199.98, '2024-09-21', 'Credit Card');

    -- Commit the transaction if both inserts are successful
    COMMIT TRANSACTION;
    PRINT 'Transaction committed successfully.';
END TRY
BEGIN CATCH
    -- If an error occurs, roll back the transaction
    ROLLBACK TRANSACTION;
    PRINT 'Transaction rolled back due to an error.';
END CATCH;


# Run and show

# Error!

# Data Manipulation Language (DML) statements are not supported for this table type in this version of SQL Server.





















