##########################
# d-01-CreatingADatawarehouseAndLoadingDataUsingCOPYINTO
##########################

-------------------------------------------------------------
# BEHIND the scenes in MS Fabric

# Clear up the existing workspace of all items from the previous Data Lakehouse path

# You can delete the workspace and recreate

# We will start this on a completely fresh slate

-------------------------------------------------------------
# BEHIND the scenes in Azure Portal

# We first need to set up the data that we load into the warehouse on ADLS

# We will not show all the steps - only a subset of the steps

# Set up the storage account

loonyfabricstorage

# Resource group

loony-fabric

# Primary service 

Azure Blob Storage or ADLS Gen2

# Primary workload

Big Data Analytics

# Stick with 

locally redundant storage

# Click on Next

# Make sure Hierarchical namespaces are enabled!

# Click on "Review + Create" -> "Create"


# Go to the resource -> Click on Containers on the left

# Within that, navigate to Containers and create a loonyfabriccontainer

######################################################
############ NOTES:

# Details of the storage account and container to be mentioned in VOs

# We're using ADLS Gen2 to store our data Azure Data Lake Storage (ADLS) is a scalable, high-performance data storage solution in Azure designed specifically for big data analytics. Gen 2 includes hierarchical namespaces (that we have enabled) a feature that organizes data within Azure Data Lake Storage Gen2 more efficiently by enabling a directory-like structure for organizing files and folders. This structure provides a way to manage data in a more granular and file system-like manner.

# Best practice is to enable hierarchical namespaces - needed when creating shortcuts and though we will not be creating shortcuts we have this enabled

######################################################


# Dataset: https://www.kaggle.com/datasets/aungpyaeap/supermarket-sales


----------------------------------------------------------------
# Start recording from here:

# Start on the Azure Portal

# Click on the loonyfabricstorage storage account

# Show the details of the resources

# You can see "Account kind" is "V2" this is ADLS Gen 2

# Under "Data Lake Storage" in the section below you can see hierarchical namespaces enabled

# Click on the container

# IMPORTANT: Show the two files that we're uploading to the container

supermarket_sales_no_header.csv

supermarket_sales.csv

# Upload the supermarket_sales_no_header.csv file to ADLS

# Upload the supermarket_sales.csv file to ADLS

# NOTE: The only difference is the header

-----------------------------------------------------------------------------------

# Now switch over to the MS Fabric portal - we should be in the "Home" view

# On the bottom-left switch to the Data Warehouse view

# Click on "Workspaces" on the left and show that we have a "loony-workspace" already created

# Select the workspace and create a new warehouse

loony-warehouse

# This brings up the Explorer view of the warehouse showing you warehouse details and queries 

--------------------
# Another way to create a warehouse 

# On the left click on +Create

# Go to the "Data Warehouse" section and click on that

# The same dialog pops up

# Click on the loony-workspace

# Notice that we have the warehouse and a default semantic model associated with the warehouse

# If you remember when we created the lakehouse there was a default semantic model associated with that as well

# NOTES: Semantic models set up relationships and metrics on top of warehouse tables to make it easier for users to work with warehouse data


------------------------------------------

# Create a "New SQL Query" and create a blank query

# Rename it to 

WarehouseQueries


# Run this command

CREATE TABLE [SupermarketSales] (
    [InvoiceID] VARCHAR(20),
    [Branch] CHAR(1),
    [City] VARCHAR(50),
    [CustomerType] VARCHAR(20),
    [Gender] VARCHAR(10),
    [ProductLine] VARCHAR(50),
    [UnitPrice] DECIMAL(10, 2),
    [Quantity] INT,
    [Total] DECIMAL(10, 4),
    [SaleDate] DATE,
    [Payment] VARCHAR(20)
);




# Expand the "Schemas" -> "dbo" on the left 

# Show that the new table has been created in the default dbo schema (a schema is just a logical grouping of tables, views, functions, and stored procedures)


# IMPORTANT: Close the explorer on the left and make sure you have more room for your SQL queries


# Now we're ready to copy data into this table


-------------------------------------------------------------------------


# Back to the Azure Portal

# IMPORTANT: Go to the loonyfabricstorage resource view

# Now click on the "Shared access signature" in the sidebar

# Let's give full permissions on the storage account

# Hover over help icon for "Allowed services" -> leave as is

# Hover over help icon for "Allowed resource types" -> Choose all 3 (Service, Container, Object)

# Hover over help icon for "Allowed permissions" -> Leave as is (we will be writing error files to the container so we need the write permissions as well)

# Click on "Generate SAS and connection string"

# Copy over the SAS token - we will need this to authenticate ourselves

# NOTES: SAS (Shared Access Signature) is a secure token that grants limited access to Azure Storage resources, such as blobs, queues, or files, without exposing your account keys.


# On the left go to "Data storage" -> "Containers" and click on "loonyfabriccontainer"

# Now click on "Properties" - note the URL of the container - we will need to use this in the copy command


--------------------------------------------------------

# Back to Fabric


COPY INTO SupermarketSales
FROM 'https://loonyfabricstorage.blob.core.windows.net/loonyfabriccontainer/supermarket_sales_no_header.csv'
WITH (
    FILE_TYPE = 'CSV',
    CREDENTIAL=(IDENTITY= 'Shared Access Signature', SECRET='fill_in_secret')
)

# Show how many records have been loaded

SELECT COUNT(*) from SupermarketSales;

# This should be 1000

# Click on "Data" at the bottom left of the page

# Show the records in the table - everything has been loaded perfectly with the right data types


---------------------------------------------------------

# Now let's load the files with header (we'll just load into the same table)


COPY INTO SupermarketSales
FROM 'https://loonyfabricstorage.blob.core.windows.net/loonyfabriccontainer/supermarket_sales.csv'
WITH (
    FILE_TYPE = 'CSV',
    CREDENTIAL=(IDENTITY= 'Shared Access Signature', SECRET='fill_in_secret')
)

# This will cause an error because of the header

# Error encountered while parsing data: 'Column name conversion error'. Underlying data description: file 'https://loonyfabricstorage.blob.core.windows.net/loonyfabriccontainer/supermarket_sales.csv'.


# This is because the column header types (all strings) do not match the data types of the individual columns

# The data has not been loaded into the table

SELECT COUNT(*) from SupermarketSales;

# This should still be 1000


-------------------------------------------------------------------------------
# You can skip the header row - this copy will succeed

COPY INTO SupermarketSales
FROM 'https://loonyfabricstorage.blob.core.windows.net/loonyfabriccontainer/supermarket_sales.csv'
WITH (
	FIRSTROW=2,
    FILE_TYPE = 'CSV',
    CREDENTIAL=(IDENTITY= 'Shared Access Signature', SECRET='fill_in_secret')
)

# This should show 2000 records

SELECT COUNT(*) from SupermarketSales;

# Click on "Data" at the bottom left and show the data for the table

# Notice all the data types look correct


----------------------------------------------------------------------------
# Exploring other options in COPY



# We'll first delete the records in the table (this would not have been possible with the analytics endpoint on a lakehouse)

DELETE FROM SupermarketSales

# Note we do not skip the header row, that one error will be tolerated

COPY INTO SupermarketSales
FROM 'https://loonyfabricstorage.blob.core.windows.net/loonyfabriccontainer/supermarket_sales.csv'
WITH (
    MAXERRORS=1,
    FILE_TYPE = 'CSV',
    CREDENTIAL=(IDENTITY= 'Shared Access Signature', SECRET='fill_in_secret')
)

# 1000 records loaded

# NOTE that we cannot see that there were any errors encountered at all! 

SELECT COUNT(*) from SupermarketSales;

# Click on "Data" at the bottom left and show the data for the table

# Notice all the data types look correct

-----------------------------------------

# If we want to know whether any errors were encountered due to the copy we can store the loading error details in an error file

# Show the rows in the SupermarketSales table

COPY INTO SupermarketSales
FROM 'https://loonyfabricstorage.blob.core.windows.net/loonyfabriccontainer/supermarket_sales.csv'
WITH (
    MAXERRORS=1,
    ERRORFILE='https://loonyfabricstorage.blob.core.windows.net/loonyfabriccontainer/errorfile_supermarket_sales',
    ERRORFILE_CREDENTIAL=(IDENTITY='Shared Access Signature', SECRET='fill_in_secret'),
    FILE_TYPE='CSV',
    CREDENTIAL=(IDENTITY= 'Shared Access Signature', SECRET='fill_in_secret')
)

# Show the rows in the SupermarketSales table
# Go back to ADLS and show the new errors_supermarket_sales folder

# Click through the subfolders until you find the error.json and row.csv files
# You have to click "_rejectedrows"


# Download and show those files in Sublimetext - the error is from the header row

# IMPORTANT: Make sure you use line wrap when you show those files so we can see the contents clearly







