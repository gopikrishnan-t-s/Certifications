##############################
# d-02-RunningTSQLQueriesOnWarehouses
##############################



# Make sure the left pane is closed

# Use the same WarehouseQueries SQL query


# Create a new SQL query and run each of the following queries

# Select all rows and columns from the table

SELECT * 
FROM SupermarketSales

# Filter the rows in the table

SELECT * 
FROM SupermarketSales
WHERE CustomerType = 'Member';

# Select specific columns from the table

SELECT Branch, CustomerType, ProductLine, Quantity, UnitPrice
FROM SupermarketSales;

# Grouping and ordering

SELECT 
    ProductLine, 
    SUM(Total) AS TotalSales
FROM 
    SupermarketSales
GROUP BY 
    ProductLine
ORDER BY 
    TotalSales DESC;


# Here we create a pivot table using T-SQL

SELECT 
    ProductLine, 
    [January], 
    [February], 
    [March]
FROM 
    (SELECT 
         ProductLine, 
         DATENAME(MONTH, SaleDate) AS Month, 
         Total
     FROM 
         SupermarketSales
    ) AS SourceTable
PIVOT 
    (SUM(Total) FOR Month IN ([January], [February], [March])) AS PivotTable;





---------------------------------------------------
---------------------------------------------------


# These were all read operations. Let's now perform some DML operations

# Existing records (should be 2000)

SELECT COUNT(*) from SupermarketSales;


# Insert data into the table

INSERT INTO SupermarketSales (InvoiceID, Branch, City, CustomerType, Gender, ProductLine, UnitPrice, Quantity, Total, SaleDate, Payment)
VALUES 
    ('INV10234', 'A', 'New York', 'Member', 'Female', 'Electronics', 99.99, 3, 299.97, '2024-09-21', 'Credit card'),
    ('INV10235', 'B', 'Los Angeles', 'Normal', 'Male', 'Groceries', 25.50, 10, 255.00, '2024-09-20', 'Cash'),
    ('INV10236', 'C', 'Chicago', 'Member', 'Female', 'Clothing', 49.99, 4, 199.96, '2024-09-19', 'Debit Card'),
    ('INV10237', 'A', 'Houston', 'Normal', 'Male', 'Home Appliances', 199.99, 1, 199.99, '2024-09-18', 'Mobile Payment'),
    ('INV10238', 'B', 'San Francisco', 'Member', 'Female', 'Health & Beauty', 15.99, 6, 95.94, '2024-09-17', 'Credit card');

# After insertion records (should be 2005)

SELECT COUNT(*) from SupermarketSales;


-------------------

# Let's look at the existing records

SELECT * from SupermarketSales
WHERE Payment = 'Mobile Payment';


# Should be 1 entry

UPDATE SupermarketSales
SET Payment = 'Mobile Payment'
WHERE Payment = 'Credit card'
AND SaleDate BETWEEN '2024-01-01' AND '2024-09-30';

# 2 records updated

SELECT * from SupermarketSales
WHERE Payment = 'Mobile Payment';

# Now should be 3 entries


----------------------

# Number of records before delete

SELECT COUNT(*) from SupermarketSales;

# Delete

DELETE FROM SupermarketSales
WHERE SaleDate BETWEEN '2019-01-01' AND '2019-01-31';

# 704 records deleted

SELECT COUNT(*) from SupermarketSales;

# Should show 1301 records

################################################################################

# Can ingest data into warehouses using T-SQL Create Table AS command

# The CREATE TABLE AS SELECT (CTAS) statement allows you to create a new table in your warehouse from the output of a SELECT statement. It runs the ingestion operation into the new table in parallel, making it highly efficient for data transformation and creation of new tables in your workspace.

CREATE TABLE [dbo].[MandalaySales] AS
SELECT *
FROM [dbo].[SupermarketSales]
WHERE [City] = 'Mandalay';

# Confirm table created

SELECT * from [dbo].[MandalaySales];

# Another example of CTAS to create a table with granular date information (helpful with visualization)

CREATE TABLE [dbo].[SupermarketSales_with_Year_Month_Day] AS
SELECT 
    DATEPART(YEAR, [SaleDate]) AS [Year],
    DATEPART(MONTH, [SaleDate]) AS [Month],
    DATEPART(DAY, [SaleDate]) AS [DayOfMonth],
    *
FROM 
    [dbo].[SupermarketSales];


# Query table and show new columns

SELECT * from SupermarketSales_with_Year_Month_Day;




---------------------------------------------------

# Create an empty SupermarketSales_2024 table with the same columns as SupermarketSales, so you can then insert data into it later with an INSERT INTO query.

CREATE TABLE [dbo].[SupermarketSales_2024] AS
SELECT * 
FROM [dbo].[SupermarketSales]
WHERE 1 = 0;  -- This creates an empty table with the same structure




INSERT INTO [dbo].[SupermarketSales_2024]
SELECT * 
FROM [dbo].[SupermarketSales]
WHERE [SaleDate] > '2024-01-01';




SELECT * FROM [dbo].[SupermarketSales_2024];

# Should have 5 records


################################################################################
# Transactions in a warehouse

# Two insertions using a transactions for branch = Z

BEGIN TRANSACTION;

BEGIN TRY
    -- Insert first record
    INSERT INTO [dbo].[SupermarketSales] 
        (InvoiceID, Branch, City, CustomerType, Gender, ProductLine, UnitPrice, Quantity, Total, SaleDate, Payment)
    VALUES 
        ('INV10240', 'Z', 'New York', 'Normal', 'Male', 'Groceries', 15.99, 10, 159.90, '2024-09-21', 'Cash');

    -- Insert second record
    INSERT INTO [dbo].[SupermarketSales] 
        (InvoiceID, Branch, City, CustomerType, Gender, ProductLine, UnitPrice, Quantity, Total, SaleDate, Payment)
    VALUES 
        ('INV10241', 'Z', 'Los Angeles', 'Member', 'Female', 'Electronics', 99.99, 2, 199.98, '2024-09-21', 'Credit Card');

    -- Commit the transaction if both inserts are successful
    COMMIT TRANSACTION;
    PRINT 'Transaction committed successfully.';
END TRY
BEGIN CATCH
    -- If an error occurs, roll back the transaction
    ROLLBACK TRANSACTION;
    PRINT 'Transaction rolled back due to an error.';
END CATCH;


# Will be successful


# Should see 2 records

SELECT * FROM SupermarketSales
WHERE Branch = 'Z';

---------------------------------------------------------

# A transaction with an error in the second INSERT

# Notice the junk value after Electronics for "UnitPrice"


BEGIN TRANSACTION;

BEGIN TRY
    -- Insert first record
    INSERT INTO [dbo].[SupermarketSales] 
        (InvoiceID, Branch, City, CustomerType, Gender, ProductLine, UnitPrice, Quantity, Total, SaleDate, Payment)
    VALUES 
        ('INV10240', 'Z', 'New York', 'Normal', 'Male', 'Groceries', 15.99, 10, 159.90, '2024-09-21', 'Cash');

    -- Insert second record
    INSERT INTO [dbo].[SupermarketSales] 
        (InvoiceID, Branch, City, CustomerType, Gender, ProductLine, UnitPrice, Quantity, Total, SaleDate, Payment)
    VALUES 
        ('INV10241', 'Z', 'Los Angeles', 'Member', 'Female', 'Electronics', 'asdasdsad', 2, 199.98, '2024-09-21', 'Credit Card');

    -- Commit the transaction if both inserts are successful
    COMMIT TRANSACTION;
    PRINT 'Transaction committed successfully.';
END TRY
BEGIN CATCH
    -- If an error occurs, roll back the transaction
    ROLLBACK TRANSACTION;
    PRINT 'Transaction rolled back due to an error.';
END CATCH;

# Transaction rolled back

# Statement ID: {FDC00921-D173-4C1F-A3B4-91282716CFD8} | Query hash: 0xC0CB2AE012CA007B | Distributed request ID: {CDFBA58C-83B9-44B9-925A-2241479B7C79}
# Msg 15806, Level 0, State 1
# (1 records affected)
# (0 records affected)
# Transaction rolled back due to an error.


# Still just 2 records

SELECT * FROM SupermarketSales
WHERE Branch = 'Z';

