############################
# d-03-WorkingWithDirectLake
############################

# NOTES:

# In this demo, we will be doing Direct Lake
# This is a way of importing data into Power BI that is very quick
# It will directly access the data from the lakehouse
# Unlike DirectQuery, which sends a query to the lakehouse and is slower
# Import mode is fast, but stores all data in memory
# So it finds it difficult to handle large datasets

# We will demonstrate how to use Direct Lake and the performance improvements it gives us
----------------------

# Start in the loony-workspace

# Create a new lakehouse 

LoonyLakehouse

# Upload the global_superstore_large dataset to that lakehouse
# Create a new table from this dataset

global_superstore_large

# Now click on New Semantic Model
# Name this semantic model 

Global Superstore Model

# Note that in the dialog it says Direct Lake Semantic Model

# Add the global_superstore_large table to this model

# Click on the table card in the model view -> Properties -> Advanced - it will say storage mode is Direct Lake

# Now click on Model --> Semantic Model --> Properties --> General

# Show the drop down for "Direct Lake Behavior"
# Here you will see that the mode is Automatic

# Click on the "Value filter behavior" drop down and see the options

##############################
# NOTES
# This means that for datasets with less than 1.5B rows, Power BI will use Direct Lake for reports
# If the dataset is larger than 1.5B rows, Power BI will use the slower Direct Query mode
# 1.5B is the limit for Fabric workspaces with capacity F64 and above
# Coalesced (Traditional behavior):
# Filters on multiple columns from the same table are combined into one.
# Only combinations of filter values that actually exist in the data are considered.
# This can lead to unexpected results, especially with sparse data.
# Example: If you filter Year = 2024 and Color = Blue or Red, but there are no red products in 2024, the effective filter becomes Year = 2024 and Color = Blue.
# Independent (New behavior):
# Filters on multiple columns from the same table are kept separate.
# Each filter is applied independently, without combining them.
# This often leads to more intuitive results, especially when dealing with filters that might not have overlapping values.
# Example: Using the same filters (Year = 2024 and Color = Blue or Red), it will include all blue and red products, even if there are no red products in 2024.
##############################

# Leave the automatic model for now - it will pick Direct Lake because we have around 500K rows in our table

---------------------
# Go to the Lakehouse view and create a new notebook

Superstore Queries

# We will be viewing the inner workings of DirectLake and DirectQuery in this notebook

# First, import some common libraries

import pyspark.sql.functions as F
from sempy import fabric

# Next, we will run a DAX command to view the columns (measures, to be more precise) in our semantic model
# This will tell us whether that measure (column is a subtype of measure) has been accessed recently
# It will also tell us the size of the measure, and when it was last accessed (in UTC)
# Run this query now

before_report_memory_df = fabric.evaluate_dax("Global Superstore Model",
                                            """SELECT MEASURE_GROUP_NAME,
                                                      ATTRIBUTE_NAME,
                                                      DATATYPE,
                                                      DICTIONARY_ISRESIDENT,
                                                      DICTIONARY_SIZE,
                                                      DICTIONARY_TEMPERATURE,
                                                      DICTIONARY_LAST_ACCESSED
                                                FROM $SYSTEM.DISCOVER_STORAGE_TABLE_COLUMNS
                                                ORDER BY [DICTIONARY_TEMPERATURE] DESC""")
before_report_memory_df.head(50)

#################################
### NOTES
# The query retrieves information about storage table columns in a Microsoft Analysis Services or Power BI model. Each selected column in the query provides specific insights into the attributes and storage characteristics of the data. Here’s a breakdown of each column:

# MEASURE_GROUP_NAME: This column shows the name of the measure group or table in the model to which the attribute belongs. Measure groups are collections of measures (like sales amount, quantity) that are logically grouped together, often corresponding to a single fact table in a star schema.

# ATTRIBUTE_NAME: This column represents the name of the attribute or column within the measure group. Attributes are typically dimensions or fields in the table, such as product name or customer ID, which provide context to the measures.

# DATATYPE: Specifies the data type of the attribute (e.g., integer, string, date). Knowing the data type helps in understanding how the attribute is stored and processed within the model.

# DICTIONARY_SIZE: Shows the memory size of the dictionary for the attribute, typically in bytes. The dictionary is a storage structure used for encoding unique values in a column to save space. A large dictionary size indicates that the attribute has many unique values or requires more memory to store the dictionary.

# DICTIONARY_TEMPERATURE:
# A scaled numeric value indicating the frequency of dictionary access.
# It's based on the most recent access time and usage.
# Higher values suggest more frequent access.
# This value is NULL if the dictionary is not pageable or hasn't been loaded.

# DICTIONARY_LAST_ACCESSED: Shows the last time the dictionary was accessed. This can help identify columns that are infrequently used and may be candidates for optimization or removal to free up memory.
#################################

# We access this data from a system-maintained table

# Note that the last four columns are blank for all of the rows

# This is because none of them have been queried recently, so they are not in memory

------------------------------


# Now switch back to the semantic model editor

# Right-click on the global_superstore_large table on the right

# Uncheck "Hide in report view"

# Create a new Power BI report from this semantic model

# Name this report (save the report and it will ask you to name it)

Superstore Analysis

# In that, create a table from Country and Sum of Profit

# This is very quick - don't forget that our dataset has 500K odd rows

# Add a card and add the  count(distinct) of OrderID - this will show you the count of orders

----------------------------------

# Now switch back to our notebook - run this cell of code (it is the same as earlier, just names changed):

after_report_memory_df = fabric.evaluate_dax("Global Superstore Model",
                                            """SELECT MEASURE_GROUP_NAME,
                                                      ATTRIBUTE_NAME,
                                                      DATATYPE,
                                                      DICTIONARY_ISRESIDENT,
                                                      DICTIONARY_SIZE,
                                                      DICTIONARY_TEMPERATURE,
                                                      DICTIONARY_LAST_ACCESSED
                                                FROM $SYSTEM.DISCOVER_STORAGE_TABLE_COLUMNS
                                                ORDER BY [DICTIONARY_TEMPERATURE] DESC""")
after_report_memory_df.head(50)

# Now, the columns that we used in the report have values for the last 3 columns
# And the time last accessed can be cross-checked

------------------------------
# Now go back to the semantic model editor

# Click through to the Semantic Model Properties

# Change the mode to be DirectQuery only

# Go back to our Power BI report

# From both the table and the card - remove the columns they display

# Now explicitly re-add the columns (Country and Profit)

# Now explicitly re-add the columns (Count distinct of OrderID)

# Note that this time, the Power BI report takes slightly longer to generate

# This is because DirectQuery is slower than DirectLake

# It is still fast enough for us, because our data is not too large

--------------------------------

# Go to the notebook, note the values for the dictionary_temperature

# Re-run the cell to compute

after_report_memory_df

# Note that the value of temperature for the cells we re-added has gone up

-------------------------------
# Back to the Power BI report

# Now just create a new table and add Region and Sum of ShippingCost to it

# Now create another new table and add Segment and Count of RowID to it

---------------------------------------
# Now switch back to the notebook

# Compute the columns

# Re-run the cell to compute

after_report_memory_df

# Note that Region and Segment have been added to memory BUT ShippingCost and RowID have NOT been added to memory

# Categorical columns are added to memory even with Direct Query but numeric columns are NOT










