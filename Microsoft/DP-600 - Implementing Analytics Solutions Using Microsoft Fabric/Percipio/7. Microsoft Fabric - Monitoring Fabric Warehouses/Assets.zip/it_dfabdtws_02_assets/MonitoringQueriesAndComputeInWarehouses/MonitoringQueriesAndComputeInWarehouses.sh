##############################################
# d-04-MonitoringQueriesAndComputeInWarehouses
##############################################

#########################
# Fabric Capacity Metrics
#########################

# We've seen the capacity metrics app for lakehouses, we'll see this for warehouses as well

# We've already installed the app in the previous learning path

# Just a reminder we will show them how to install the app (we will not actually install it again)

---------------------------------------------

# Start recording here

# Go to this link:

https://learn.microsoft.com/en-us/fabric/enterprise/metrics-app-install?tabs=1st

# Show the process

# Follow the install steps there

# Click on "Get it now"

################################################################
####### NOTES:

# IMPORTANT:

# In the VOs please remind the learners that when you are asked for the capacity ID the id comes from the URL just after capacities/

################################################################

# Since we already have the app now let's see how we can find the existing installed app in our workspace

# Click on the switcher on the bottom-left and choose "Power BI"

# Since the Fabric Capacity Metrics App is a Power BI app, go to the Power BI section within Fabric

# Click on "Apps"

# Click on the "Capacity Metrics App"

# Now you can see the different capacity metrics for all of the notebooks and jobs

# IMPORTANT:
# No need to click on or show any metric - we've already seen this

# In order to only monitor your warehouse you can filter by warehouse

# Now in the table in Compute select "Warehouse" in the slicer

# Note the updated metrics are all for the warehouse

# IMPORTANT:
# Note that the "loony_lakehouse" also shows up under warehouses

# Hover over the "Duration" for

loony_lakehouse # Notice this is because of the SQL queries to the endpoint
loony-warehouse # A number of activities here performed under the hood

# Switch over to "Storage"

# This does not seem to be filtered by Lakehouse or Warehouse - this is just OneLake storage under the hood


#######################################
# Monitor queries using Query Activity
#######################################


# Start in the query editor of the warehouse

# Open up a new query call it

LongRunningQuery

# Run this query:

WHILE 1 = 1
BEGIN
    -- Simulate some work
    WAITFOR DELAY '00:00:10'; -- 10 seconds delay
    SELECT * FROM SupermarketSales;
END



# Click on the warehouse and go to the "Query" view

# At the top of the page click on "Query Activity"

# This will bring up the view

# Note our long-running query is currently running

# Note the session ID for the query


# Scroll and show

# Show you can sort by column - sort by

Duration

---------------------------------------------------------

# Click on the "Query Insights" tab

# This shows us the "Long Running Queries"

# Scroll horizontally to show all the columns

# Show that we can sort by column:

Last run duration

# Select from the drop down

Frequently run queries

# Scroll horizontally to show all the columns

----------------------------------------------------------
# There is another way to access the Query Activity 

# Click on the loony-workspace

# Click on 3-dots next to the warehouse

# Click on "Query Activity"

# This shows us the same view

#######################################
# Monitor queries using DMVs
#######################################


# Remember that our while-true loop is still running

# Switch to the "Warehouse"

SELECT * FROM sys.dm_exec_connections

# IMPORTANT: Scroll to the right to show all columns

# I don't think the details here are important (based on crash course)



# Note that the session ID of our long running query is present

# Can talk about columns in for this session (use the notes above)

session_id
most_recent_session_id
encrypt_option
auth_scheme
connect_time
net_transport
protocol_type
num_reads = 1
num_writes = large number # This seems strange because I would have expected a large number of reads and no writes, seems like this is wrong


------------------------------------------

SELECT * FROM sys.dm_exec_sessions

# IMPORTANT: Scroll to the right to show all columns

# Can explain a few columns

session_id
login_time
host_name
status
program_name
login_name
is_user_process 

# Most of the columns are null

# IMPORTANT
# Sort by status so that the sessions with running status shows up on top

--------------------------------------------------------------


SELECT * FROM sys.dm_exec_requests

# Again many columns - scroll to the right and show

# Explain the following columns (use notes above)

session_id
request_id
start_time
status
command
cpu_time
logical_reads
writes
reads

---------------------------------------------------------

# You can combine the data across tables to get more meaningful info

SELECT 
    connections.connection_id,
    connections.connect_time,
    sessions.session_id, 
    sessions.login_name, 
    sessions.login_time, 
    sessions.status
FROM sys.dm_exec_connections AS connections
INNER JOIN sys.dm_exec_sessions AS sessions
ON connections.most_recent_session_id = sessions.session_id;


SELECT
    r.session_id,
    r.status,
    r.start_time,
    r.cpu_time,
    r.total_elapsed_time,
    r.plan_handle,
    st.text AS sql_text
FROM 
    sys.dm_exec_requests r
JOIN 
    sys.dm_exec_sessions s ON r.session_id = s.session_id
CROSS APPLY 
    sys.dm_exec_sql_text(r.sql_handle) st
WHERE 
    r.status = 'running';



# Note that there is a session for the SELECT and for the WHILE-TRUE loop

# Note the session ID of the WHILE-TRUE loop

# Replace the session id and kill the process

KILL 'session_id'

# Go back to the "Long Running Query" tab and show the query has been terminated

# After running this, go to Query Activity - now the while-true query has been divided into small chunks

# Each WHILE-TRUE is a different statement with the same session ID

# Each of the iterations is separately shown as Successfully Executed

# The last one (at the top) would have failed

---------------------------------------------------------------

# Show currently running requests in the same database

# PLEASE NOTE this query is from the Microsoft Fabric Learn tutorial

# This is our current database ID (here database is the data warehouse)
SELECT DB_ID();

# Now run this
SELECT 
    connections.connection_id,
    sessions.session_id, 
    sessions.login_name, 
    sessions.login_time,
    requests.command, 
    requests.start_time, 
    requests.total_elapsed_time
FROM sys.dm_exec_connections AS connections
INNER JOIN sys.dm_exec_sessions AS sessions
    ON connections.most_recent_session_id = sessions.session_id
INNER JOIN sys.dm_exec_requests AS requests
    ON requests.session_id = sessions.session_id
WHERE requests.status = 'running'
    AND requests.database_id = DB_ID()
ORDER BY requests.total_elapsed_time DESC;





#######################################
# Query Insights
#######################################




# Run this
SELECT * FROM queryinsights.exec_requests_history;

# IMPORTANT:
# Scroll horizontally to show the columns

# Explain the following columns

distributed_statement_id
submit_time
start_time
end_time
batch_id
root_batch_id (note that in our case both are usually the same)



# Now run this

SELECT * FROM queryinsights.exec_sessions_history;


# IMPORTANT:
# Scroll horizontally to show the columns

# Explain the following columns

is_user_process
# A flag (0/1) indicating whether the session is a user session (1) or a system process (0).

# The group of 0/1 commands are how the session will treat ansi values and other details

---------------------------------------------------

# Now run this

SELECT * FROM queryinsights.frequently_run_queries;

# IMPORTANT:
# SORT by number of runs (first column) in descending order
# Scroll horizontally to show the columns

# Columns here are self-explanatory


# Now run

SELECT * FROM queryinsights.long_running_queries;

# IMPORTANT:
# SORT by median_total_elapsed_time (first column) in descending order
# Scroll horizontally to show the columns


# Columns here are self-explanatory

-------------------------------------------------------

# Run this query

SELECT * FROM queryinsights.exec_requests_history 
WHERE start_time >= DATEADD(MINUTE, -60, GETUTCDATE())
AND login_name = USER_NAME();

# This query retrieves information about requests executed by the current user within the last 60 minutes from the queryinsights.exec_requests_history table in Microsoft Fabric Query Insights.

# DATEADD(MINUTE, -60, GETUTCDATE()) subtracts 60 minutes from the current UTC time, so the query filters all requests that started within that time frame.

# USER_NAME() is a system function that returns the login name of the current user executing this query.


# Run this

SELECT * FROM queryinsights.frequently_run_queries
WHERE last_run_command LIKE '%SELECT%'
ORDER BY number_of_successful_runs DESC;

# This query returns the most recent queries that match a certain string, ordered by the number of successful executions

SELECT * FROM queryinsights.frequently_run_queries
WHERE last_run_command LIKE '%SELECT%'
ORDER BY number_of_runs DESC;

# This query returns the most recent queries that match a certain string, ordered by the number of executions


SELECT * FROM queryinsights.long_running_queries
WHERE last_run_command LIKE '%SELECT%'
ORDER BY median_total_elapsed_time_ms DESC;


# This query returns the queries that match a certain string, ordered by the median query execution time descending.


















