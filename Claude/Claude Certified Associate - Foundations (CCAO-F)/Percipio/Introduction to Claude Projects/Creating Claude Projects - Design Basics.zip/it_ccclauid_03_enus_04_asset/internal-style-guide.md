# TechCraft Industries Internal Documentation Style Guide
Version 2.3 - Updated January 2025

## Core Principles
TechCraft documentation emphasizes clarity, precision, and our engineering-first culture. This guide supplements the Chicago Manual of Style for internal reports and documentation.

## Company Self-Reference Guidelines

### The "We/Our" Rule
- Never use "we" or "our" in technical documentation. Example:
  - Incorrect: "Our testing revealed a 15% performance improvement"
  - Correct: "Testing revealed a 15% performance improvement"
  - Correct: "TechCraft testing revealed a 15% performance improvement"

### Company Name Usage
- First reference: Use "TechCraft Industries" in full
- Subsequent references: Use "TechCraft"
- Never use "TC" or other abbreviations
- Exception: Financial reports may use "TCI" after first full reference

### Product Line References
- Always capitalize "Series" in product names (TC5000 Series)
- Use generation markers without spaces (TC5000G2, not TC5000 G2)
- Never use ordinal numbers for generations (Incorrect: TC5000 2nd Gen)

## Technical Writing Standards

### Data Presentation
- Round all percentages to one decimal point (15.7%, not 15.74%)
- Use metric units first, imperial in parentheses
- Present ranges with em dashes (15–20 units, not 15 to 20 units)
- Never use "approximately" or "about" - provide exact figures or ranges

### Technical Terms
- Capitalize all internal project codenames (Project BLUEHAWK, not Project Bluehawk)
- Use lowercase for general technical terms (motherboard, chipset)
- Exception: Capitalize TechCraft-specific technologies (TechCraft QuietCool™)

### Document Structure
- Begin all reports with an Executive Summary
- Use nested numbering (1.1, 1.2, etc.) for all sections
- Place all graphs before tables in each section
- Never combine graphs and tables into a single figure

## Voice and Tone
- Use active voice exclusively
- Avoid normative language ("should," "could," "might")
- State conclusions directly:
  - Incorrect: "The data suggests that the TC5000G2 might perform better"
  - Correct: "The TC5000G2 performs 23.4% faster than the previous generation"

## Unique TechCraft Conventions

### The Engineering Voice Rule
- Every claim requires a corresponding metric
- Never use qualitative assessments without quantitative support
  - Incorrect: "Performance improved significantly"
  - Correct: "Performance improved by 27.3%"

### Time References
- Use "Calendar Q" instead of "Quarter" (Calendar Q1 2025)
- Express all project timelines in weeks, not months
- Use ISO 8601 for all dates (2025-01-23)

### Prohibited Terms
- "Leading"
- "Industry-standard"
- "Revolutionary"
- "Game-changing"
- "Next-generation" (use specific generation numbers)
- "State-of-the-art"

### Required Footer
All internal reports must end with:
"TechCraft Industries Internal Document - Engineering Verified - [DATE]"