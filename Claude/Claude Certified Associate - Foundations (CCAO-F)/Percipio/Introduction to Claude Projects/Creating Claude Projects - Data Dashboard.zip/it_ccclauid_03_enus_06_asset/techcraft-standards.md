# TechCraft Data Visualization Standards

## Brand Colors
- Primary: #2563eb (TechCraft Blue)
- Secondary: #7c3aed (Innovation Purple)
- Success: #059669 (Growth Green)
- Warning: #d97706 (Alert Orange)
- Danger: #dc2626 (Critical Red)
- Neutral: #64748b (Business Gray)

## Chart Types & Naming Conventions

### Revenue Charts
- "Performance Overview" - Multi-line chart showing revenue vs targets
- "Regional Heat Map" - Geographic performance visualization
- "Product Portfolio Matrix" - Grouped bar charts for product lines
- "Growth Trajectory" - YoY comparison line charts

### Executive Dashboards
All executive presentations should use these standard components:
- "Quarterly Snapshot" - Top-level KPI cards
- "Market Position" - Competitive analysis charts
- "Strategic Initiatives" - Progress tracking visuals

## Data Context

### Historical Performance
- 2022: Market entry year, exceeded revenue targets by 15%
- 2023: Strong growth in APAC region, +45% YoY
- 2024: Supply chain challenges impacted Q2-Q3
- 2025: Focus on premium market segment with TC5000 series

### Current Business Initiatives
1. TC5000G2 Launch (Q2 2025)
   - Target: 30% margin improvement
   - Focus markets: North America, APAC
   
2. Market Share Expansion
   - Goal: Double EMEA presence by 2026
   - Strategy: Mid-market product introduction

3. Operational Excellence
   - Reduce production costs by 18%
   - Improve inventory turnover by 25%

### Key Performance Indicators
- Revenue Growth (Target: 35% YoY)
- Gross Margin (Target: 45%)
- Market Share (Target: Top 3 in each region)
- Customer Satisfaction (Target: 4.5/5)
- Product Mix (Target: 60% premium segment)

## Standard Analysis Requirements
1. Always segment analysis by:
   - Region (North America, APAC, EMEA)
   - Product Line (TC4000, TC5000)
   - Customer Segment (Enterprise, Mid-Market)

2. Critical Metrics:
   - Revenue per Product
   - Regional Performance
   - Margin Analysis
   - Growth Rates

3. Regular Reporting Periods:
   - Monthly Business Review
   - Quarterly Executive Summary
   - Annual Strategic Planning