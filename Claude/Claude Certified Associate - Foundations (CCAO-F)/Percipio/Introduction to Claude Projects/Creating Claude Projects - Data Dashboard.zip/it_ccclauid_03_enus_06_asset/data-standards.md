# TechCraft Data Standards Guide

## Data Cleaning Rules

### Product Names
- Format: TC####-X
- Examples: TC5000-A, TC4000-B
- No spaces or irregular hyphens
- Always uppercase

### Regional Classification
- North America (includes US, Canada, Mexico)
- APAC (Asia-Pacific region)
- EMEA (Europe, Middle East, Africa)
- Consistent capitalization required

### Date Formats
- Always use ISO format: YYYY-MM-DD
- Quarter notation: YYYY-Q# (e.g., 2025-Q1)
- Fiscal year starts April 1st

### Numerical Standards
- Revenue: No currency symbols, use decimal numbers
- Percentages: Decimal form (0.45 not 45%)
- Units: Whole numbers only
- Satisfaction: 1-5 scale, one decimal place

### Column Naming
- No spaces (use underscores)
- All lowercase
- Standard names:
  - date
  - region
  - product_name
  - units_sold
  - revenue
  - customer_satisfaction
  - profit_margin

## Data Quality Checks
Before analysis, verify:
1. No missing values in key fields
2. Revenue matches units * price
3. Satisfaction scores within 1-5 range
4. All regions properly categorized
5. Product names match current catalog

## Common Data Issues
- Mixed date formats from legacy systems
- Inconsistent region names from different sales teams
- Product name variations from different databases
- Currency symbol inclusion from manual entries
- Extra whitespace in exports