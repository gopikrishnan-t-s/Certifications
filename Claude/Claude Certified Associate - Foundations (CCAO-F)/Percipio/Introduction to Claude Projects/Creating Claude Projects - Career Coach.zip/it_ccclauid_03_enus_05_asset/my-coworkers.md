# Key Work Relationships

## Direct Reports

### Michael Park - Junior Project Manager
- Outstanding performer, extremely reliable
- Strong technical background and attention to detail
- Key ally in TC5000G2 project execution
- Sometimes shows frustration with engineers who don't meet his standards
- Development area: Could improve diplomatic skills

### Jenny Martinez - Project Coordinator
- Currently on Performance Improvement Plan
- Struggles with deadlines and detail orientation
- Very collaborative personality, well-liked by team
- Development area: Basic project management skills and follow-through
- PIP review date: 2025-03-15

## Peers

### David Wong - Lead Project Manager (Consumer Products Division)
- Manages parallel product line to mine
- Highly competitive, especially around resources and executive attention
- Often positions his projects as higher priority than TC5000G2
- Limited collaboration despite multiple shared stakeholders

## Management

### Lisa Taylor - Director of Project Management
- Direct manager, 2 years at TechCraft
- Supportive but extremely busy managing multiple departments
- 1:1s often cancelled or shortened
- Best way to get attention: Quick bullets over Slack, flag as urgent if needed

### James Morrison - VP of Product Development
- Known for direct, sometimes harsh communication style
- Highly focused on metrics and deadlines
- Regular criticism of project timelines in executive reviews
- Values data-driven decisions over qualitative feedback
- Important to be extremely prepared for any interaction