# Career Goals - Sarah Chen

## Primary Goal
- Secure promotion to Senior Project Manager or Program Manager role within 2 years at TechCraft Industries
  - This would involve managing multiple project streams and having other project managers report to me
  - Need to demonstrate ability to handle higher-level strategic planning beyond individual project success

## Development Areas
- Build stronger executive presence and communication skills for senior management interactions
- Develop skills in multi-project portfolio management
- Improve ability to influence across departments without direct authority
- Learn to manage and develop other project managers

## Success Metrics
- Successfully deliver TC5000G2 project and other key initiatives
- Build strong relationships with VP and other senior leadership
- Demonstrate ability to mentor and develop team members
- Show impact beyond immediate project responsibilities