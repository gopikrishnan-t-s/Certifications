# Professional Background - Sarah Chen

## Education
- B.S. Electrical Engineering, Stanford University (2021)
- Senior Thesis: "Thermal Management Systems in Next-Generation Processors"
- Relevant Coursework: Project Management, Technical Leadership, Circuit Design

## Internship Experience
- Hardware Engineering Intern, Intel (Summer 2020)
  - Worked on processor testing and validation
  - First exposure to large-scale project management

- Product Development Intern, NVIDIA (Summer 2019)
  - Assisted with thermal design projects
  - Learned basics of hardware development lifecycle

- Engineering Intern, Tesla (Summer 2018)
  - Component testing and validation
  - Experience with fast-paced hardware development

## Gap Year (2021-2022)
- Independent travel through Asia and Europe
- Developed cross-cultural communication skills
- Led several volunteer technical education initiatives
- Built personal network of international tech professionals

## Current Role
- Lead Project Manager, TechCraft Industries (2022-present)
- Promoted from Project Manager after 18 months
- Currently leading TC5000G2 processor development
- Managing team of 3 direct reports
- Responsible for $15M annual project budget